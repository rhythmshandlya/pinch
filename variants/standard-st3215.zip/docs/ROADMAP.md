# Roadmap: idea → one robu.in order → walking crab

**Strategy:** do everything possible in software first, then place **one combined order**
(servos, electronics, 3D prints, screws, cables and a beginner tool kit). We won't test real
servos before buying, so the simulator uses published measurements of the exact servo and keeps
generous torque margins.

## Phase A: order-ready (everything except GPU training and assembly)

| # | Milestone | Done when | Status |
|---|---|---|---|
| A1 | Simulation v0 | Stands, 6 emotes within servo limits (`sim/check.py` passes) | ✅ |
| A2 | Scripted walking | Trot + crawl, 6 directions, within servo limits (`sim/walk.py` passes) | ✅ |
| A3 | Realistic motor model | Rhoban BAM measured ST3215 model + 5 ms latency; tests check both the measured and datasheet servo | ✅ (backlash not modelled) |
| A4 | CAD (build123d) | 10 parts / 26 pieces as STL + STEP; print rules, servo fit, 100/100 poses collision-free (`cad/check.py`) | ✅ |
| A5 | Sim from CAD | CAD meshes + mass/inertia per body (2.02 kg); CAD-derived joint limits; A1/A2 still pass | ✅ |
| A6 | Electronics | [electronics.md](../hardware/electronics.md): diagram, wiring table, simulated power budget, ID map, safety | ✅ |
| A7 | Robot software | `robot/`: real/sim backends, calibration, safety, emotes, gait, policy; `selftest.py` 10/10 in sim | ✅ (real backend untested without hardware) |
| A8 | RL pipeline | MJX env, rewards, motor-model randomisation, Colab notebook, CPU smoke test | ✅ |
| A9 | Brain v0 | Gemma 4 via Ollama, eye camera + text → clamped actions; loop tested with the stand-in brain | ✅ (needs `ollama pull gemma4:e4b` to run for real) |
| A10 | Order pack | [BOM.md](../hardware/BOM.md) ≈ ₹85.6k required + print sheet | ✅ |
| A11 | Beginner docs | [ASSEMBLY.md](../hardware/ASSEMBLY.md) | ✅ |

## Phase B: needs a GPU (Colab / cloud)

- B1: train the walking policy in MuJoCo Playground with domain randomisation (mass, friction, motor strength, latency, sensor noise).
- B2: evaluate in sim against the scripted trot, and export the policy (ONNX) for the Raspberry Pi.

## Phase C: physical build

- C1: place the order (one cart + one print upload).
- C2: set servo IDs and calibrate zero positions (scripts from A7).
- C3: first power-up on a current-limited bench supply. Emotes first (no balance needed).
- C4: scripted trot on the real robot, then the learned policy.
- C5: measure real servo behaviour, update the sim, retrain if needed (closing the sim-to-real gap).
- C6: brain on the robot (Jetson / Pi + offboard PC).

## Why this order

Each step catches mistakes before they cost money. The sim found that the claws pulled the centre of
mass forward and that the legs ran out of reach, both fixed before any purchase. The motor model
comes before RL, because a policy trained on idealised motors falls over on real ones. CAD comes
before the order because printed parts set the real masses and the screw/bracket count.
