"""Single source of truth for the crab's geometry, masses and servo model.

Units: metres, kilograms, radians, newton-metres.
Body frame: +x = front (eyes/claws), +y = left, +z = up.

Everything here is a first guess sized around the Waveshare ST3215 serial-bus
servo (same part as Feetech STS3215, sold on robu.in, SKU R258500). Masses and
actuator dynamics must be re-measured once real parts arrive (system ID).
"""

from dataclasses import dataclass, field
from math import radians


@dataclass(frozen=True)
class Servo:
    """ST3215-7.4V (= Feetech STS3215 C001). See hardware/ST3215_reference.md."""
    name: str = "ST3215-7.4V"
    bus_model: str = "sts3215"        # register map / protocol variant in robot/feetech_bus.py
    stall_torque: float = 1.91        # datasheet, 19.5 kg*cm @ 7.4 V -> what designs are CHECKED against
    safe_torque: float = 0.65         # ~1/3 stall: what we want to stay under in steady poses
    max_speed: float = 4.8            # rad/s we allow a controller to COMMAND (datasheet no-load 5.45)
    mass: float = 0.055
    # Measured motor model: Rhoban BAM "feetech_sts3215_7_4V", model m1
    vin: float = 7.4                  # servo bus voltage (regulated)
    kt: float = 1.17763               # N*m/A (identified)
    resistance: float = 2.47868       # ohm
    firmware_kp: int = 32             # servo P gain register (factory / Open Duck value)
    armature: float = 0.026083        # kg*m^2 reflected rotor inertia
    frictionloss: float = 0.05152     # N*m Coulomb friction
    friction_viscous: float = 0.05989 # N*m*s/rad
    command_delay: float = 0.005      # s, bus + firmware latency (BAM m3-m6 ~5 ms)

    # MuJoCo position-actuator equivalent (BAM to_mujoco):
    @property
    def kp(self) -> float:            # ~18.1 N*m/rad
        return 0.166 * self.firmware_kp * self.vin * 0.97 * self.kt / self.resistance

    @property
    def kv(self) -> float:            # damping lives in the joint (back-EMF), not the actuator
        return 0.0

    @property
    def force_limit(self) -> float:   # ~3.52 N*m: measured model's max torque (> datasheet stall!)
        return self.vin * self.kt / self.resistance

    @property
    def damping(self) -> float:       # ~0.62: viscous + back-EMF (kt^2/R) -> torque-speed curve
        return self.friction_viscous + self.kt ** 2 / self.resistance


@dataclass(frozen=True)
class Body:
    # Carapace modelled as an ellipsoid: wider (y) than long (x), like a real crab.
    half_size: tuple = (0.075, 0.11, 0.032)
    mass: float = 0.93                # 6 servos in body + battery + compute + shell


@dataclass(frozen=True)
class Leg:
    coxa_len: float = 0.032           # CAD: coxa bracket must clear the yaw servo's case corners
    femur_len: float = 0.070
    tibia_len: float = 0.100
    foot_radius: float = 0.009
    coxa_mass: float = 0.07           # carries femur servo
    femur_mass: float = 0.08          # carries tibia servo
    tibia_mass: float = 0.04
    # Ranges checked against the CAD for self-collision (cad/limits.py, 3 deg margin)
    coxa_range: tuple = (radians(-60), radians(60))         # rear legs
    front_coxa_range: tuple = (radians(-60), radians(42))   # front legs: forward swing meets the claw arm
    femur_range: tuple = (radians(-41), radians(90))        # below -41 the thigh hits its hip bracket
    tibia_range: tuple = (radians(-142), radians(30))       # deeper folds hit the hip bracket

    def coxa_range_for(self, leg_id: str) -> tuple:
        return self.front_coxa_range if leg_id[0] == "F" else self.coxa_range


@dataclass(frozen=True)
class Arm:
    shoulder_offset: float = 0.032    # yaw -> pitch axis; same printed bracket as the leg coxa
    upper_len: float = 0.055
    fore_len: float = 0.050
    claw_len: float = 0.060
    upper_mass: float = 0.07          # carries shoulder-pitch servo
    fore_mass: float = 0.07           # carries elbow servo
    claw_mass: float = 0.06           # carries claw servo + fixed jaw
    jaw_mass: float = 0.012
    shoulder_yaw_range: tuple = (radians(-8), radians(42))  # CAD: claws cross / arm meets front leg
    shoulder_pitch_range: tuple = (radians(-40), radians(100))
    elbow_range: tuple = (radians(-30), radians(120))
    claw_range: tuple = (radians(0), radians(55))


@dataclass(frozen=True)
class CrabParams:
    servo: Servo = field(default_factory=Servo)
    body: Body = field(default_factory=Body)
    leg: Leg = field(default_factory=Leg)
    arm: Arm = field(default_factory=Arm)
    # Left-side mounts (right side is mirrored automatically): name -> ((x, y, z), yaw)
    # Legs sit ~1.5 cm ahead of the carapace centre because the claws pull the
    # CoM forward; this keeps the CoM near the middle of the feet.
    # CAD interference checks moved the front legs back / more sideways and the arms
    # forward / inward, so a raised claw clears the front hip bracket.
    leg_mounts: dict = field(default_factory=lambda: {
        "F": ((0.040, 0.087, 0.0), radians(64)),
        "R": ((-0.036, 0.087, 0.0), radians(116)),
    })
    arm_mount: tuple = ((0.074, 0.036, 0.008), radians(28))


PARAMS = CrabParams()

# Actuated joints in a fixed order: the action vector for sim, RL and real robot.
LEG_IDS = ["FL", "FR", "RL", "RR"]
ARM_IDS = ["L", "R"]
LEG_JOINTS = ["coxa", "femur", "tibia"]
ARM_JOINTS = ["shoulder_yaw", "shoulder_pitch", "elbow", "claw"]

JOINT_NAMES = [f"{leg}_{j}" for leg in LEG_IDS for j in LEG_JOINTS] + \
              [f"{arm}_{j}" for arm in ARM_IDS for j in ARM_JOINTS]

# Sign conventions (identical on both sides thanks to mirroring):
#   coxa +           foot swings forward
#   femur +          knee lifts up
#   tibia +          foot swings outward (negative = tucked under)
#   shoulder_yaw +   arm swings outward
#   shoulder_pitch + arm lifts up
#   elbow +          forearm folds inward, toward the face
#   claw +           claw opens
