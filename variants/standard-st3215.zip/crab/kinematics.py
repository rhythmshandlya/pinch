"""Leg forward / inverse kinematics in the body frame (+x front, +y left, +z up).

Right legs are mirror images of left legs, and the joint sign conventions are
mirrored too, so a right leg's IK is the left leg's IK on the y-mirrored target.
The same code runs in sim and on the real robot.
"""

import numpy as np

from .params import LEG_IDS, PARAMS

L = PARAMS.leg


def _mount(leg_id):
    (x, y, z), yaw = PARAMS.leg_mounts[leg_id[0]]
    return np.array([x, y, z]), yaw


def _mirror(p, leg_id):
    return p if leg_id[1] == "L" else p * np.array([1, -1, 1])


def leg_fk(leg_id: str, q) -> np.ndarray:
    """(coxa, femur, tibia) -> foot centre position in body frame."""
    c, f, t = q
    m, yaw = _mount(leg_id)
    r = L.coxa_len + L.femur_len * np.cos(f) + L.tibia_len * np.cos(f + t)
    h = L.femur_len * np.sin(f) + L.tibia_len * np.sin(f + t)
    a = yaw - c                      # coxa + swings the foot forward
    return _mirror(m + np.array([r * np.cos(a), r * np.sin(a), h]), leg_id)


def leg_ik(leg_id: str, p) -> tuple[np.ndarray, bool]:
    """Foot target in body frame -> (coxa, femur, tibia), reachable flag.

    Knee-up solution (tibia bends down). Unreachable targets are projected to
    the nearest reachable distance and joints are clipped to their ranges;
    the flag tells you that happened.
    """
    m, yaw = _mount(leg_id)
    d = _mirror(np.asarray(p, float), leg_id) - m
    c = yaw - np.arctan2(d[1], d[0])
    c = (c + np.pi) % (2 * np.pi) - np.pi
    r = np.hypot(d[0], d[1]) - L.coxa_len
    h = d[2]
    D = np.hypot(r, h)
    lo, hi = abs(L.femur_len - L.tibia_len) + 1e-4, L.femur_len + L.tibia_len - 1e-4
    ok = lo <= D <= hi
    D = np.clip(D, lo, hi)
    cos_t = (D**2 - L.femur_len**2 - L.tibia_len**2) / (2 * L.femur_len * L.tibia_len)
    t = -np.arccos(np.clip(cos_t, -1, 1))
    f = np.arctan2(h, r) - np.arctan2(L.tibia_len * np.sin(t), L.femur_len + L.tibia_len * np.cos(t))
    q = np.array([c, f, t])
    rng = np.array([L.coxa_range_for(leg_id), L.femur_range, L.tibia_range])
    qc = np.clip(q, rng[:, 0], rng[:, 1])
    return qc, ok and np.allclose(q, qc)


def feet_fk(q_legs) -> dict:
    """q_legs: (4, 3) in LEG_IDS order -> {leg_id: foot pos}."""
    return {lg: leg_fk(lg, q) for lg, q in zip(LEG_IDS, q_legs)}
