"""Generate the MuJoCo model (MJCF) of the crab from crab/params.py.

    python sim/build_model.py            -> writes sim/models/crab.xml

The right side is a mirror of the left: y positions, yaw angles and z-axis
hinge axes are negated, so a given joint command means the same motion on
both sides.
"""

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from crab.emotes import STAND  # noqa: E402
from crab.params import ARM_IDS, JOINT_NAMES, LEG_IDS, PARAMS  # noqa: E402

OUT = ROOT / "sim" / "models" / "crab.xml"
P = PARAMS

# CAD outputs (python cad/build.py). When present, bodies get CAD meshes + real mass properties;
# the simple primitive shapes stay on as (hidden) collision geometry.
VIS_FILE = ROOT / "sim" / "models" / "visuals.json"
MP_FILE = ROOT / "sim" / "models" / "mass_props.json"
USE_CAD = VIS_FILE.exists() and MP_FILE.exists() and "--primitive" not in sys.argv
VIS = json.loads(VIS_FILE.read_text()) if USE_CAD else {}
MP = json.loads(MP_FILE.read_text()) if USE_CAD else {}


def f(*v):
    return " ".join(f"{x:.4g}" for x in v)


def fe(*v):
    return " ".join(f"{x:.6e}" for x in v)


BACKLASH = "--no-backlash" not in sys.argv
BACKLASH_RANGE = np.radians(0.5)      # ST3215 datasheet: backlash <= 0.5 deg (modelled like Open Duck Mini)


def bl(joint: str, axis: str) -> str:
    """Passive +-0.5 deg joint in series with a servo joint: the gear play between motor and link."""
    if not BACKLASH:
        return ""
    return f'<joint name="{joint}_backlash" class="backlash" axis="{axis}"/>'


def qpos_tree_order(q_joints) -> list:
    """Joint values in MJCF tree order, with zeros for the backlash joints (for keyframes)."""
    out = []
    for i, _ in enumerate(JOINT_NAMES):
        out.append(q_joints[i])
        if BACKLASH:
            out.append(0.0)
    return out


def cad(body: str) -> str:
    """Inertial + visual CAD meshes for a body (empty when not using CAD)."""
    if not USE_CAD or body not in MP:
        return ""
    mp = MP[body]
    out = [f'<inertial pos="{fe(*mp["com"])}" mass="{mp["mass"]:.6f}" fullinertia="{fe(*mp["inertia"])}"/>']
    for v in VIS.get(body, []):
        out.append(f'<geom class="visual" type="mesh" mesh="{v["mesh"]}" material="{v["material"]}"/>')
    return "\n        ".join(out)


def lookat_xyaxes(pos, target):
    z = np.asarray(pos, float) - np.asarray(target, float)
    z /= np.linalg.norm(z)
    x = np.cross([0, 0, 1], z)
    x /= np.linalg.norm(x)
    y = np.cross(z, x)
    return f(*x, *y)


def servo_box(name):
    # ST3215 case is ~45 x 25 x 35 mm; drawn at each joint for scale (visual only).
    if USE_CAD:
        return ""
    return (f'<geom name="{name}_servo" class="visual" type="box" '
            f'size="0.0175 0.0124 0.0226" material="servo"/>')


def leg_xml(leg_id: str) -> str:
    s = 1 if leg_id[1] == "L" else -1
    (x, y, z), yaw = P.leg_mounts[leg_id[0]]
    L = P.leg
    r = lambda rng: f(*rng)  # noqa: E731
    return f"""
      <body name="{leg_id}_coxa_link" pos="{f(x, s*y, z)}" euler="0 0 {s*yaw:.4f}">
        <joint name="{leg_id}_coxa" axis="0 0 {-s}" range="{r(L.coxa_range_for(leg_id))}"/>
        {bl(leg_id + "_coxa", f"0 0 {-s}")}
        {cad(leg_id + "_coxa_link")}
        {servo_box(leg_id + "_coxa")}
        <geom type="capsule" fromto="0 0 0 {L.coxa_len} 0 0" size="0.015" mass="{L.coxa_mass}" material="shell"/>
        <body name="{leg_id}_femur_link" pos="{L.coxa_len} 0 0">
          <joint name="{leg_id}_femur" axis="0 -1 0" range="{r(L.femur_range)}"/>
          {bl(leg_id + "_femur", "0 -1 0")}
          {cad(leg_id + "_femur_link")}
          <geom type="capsule" fromto="0 0 0 {L.femur_len} 0 0" size="0.013" mass="{L.femur_mass}" material="shell"/>
          <body name="{leg_id}_tibia_link" pos="{L.femur_len} 0 0">
            <joint name="{leg_id}_tibia" axis="0 -1 0" range="{r(L.tibia_range)}"/>
            {bl(leg_id + "_tibia", "0 -1 0")}
            {cad(leg_id + "_tibia_link")}
            {servo_box(leg_id + "_tibia")}
            <geom type="capsule" fromto="0 0 0 {L.tibia_len} 0 0" size="0.0085" mass="{L.tibia_mass}" material="shell"/>
            <geom name="{leg_id}_foot" type="sphere" pos="{L.tibia_len} 0 0" size="{L.foot_radius}" mass="0.005" material="tip" friction="1.1 0.02 0.001"/>
            <site name="{leg_id}_foot_site" pos="{L.tibia_len} 0 0" size="{L.foot_radius*1.4:.4f}" rgba="0 0 0 0"/>
          </body>
        </body>
      </body>"""


def arm_xml(arm_id: str) -> str:
    s = 1 if arm_id == "L" else -1
    (x, y, z), yaw = P.arm_mount
    A = P.arm
    r = lambda rng: f(*rng)  # noqa: E731
    palm_c, hinge, jaw_h = A.claw_len * 0.30, A.claw_len * 0.50, A.claw_len * 0.37
    return f"""
      <body name="{arm_id}_shoulder" pos="{f(x, s*y, z)}" euler="0 0 {s*yaw:.4f}">
        <joint name="{arm_id}_shoulder_yaw" axis="0 0 {s}" range="{r(A.shoulder_yaw_range)}"/>
        {bl(arm_id + "_shoulder_yaw", f"0 0 {s}")}
        {cad(arm_id + "_shoulder")}
        {servo_box(arm_id + "_shoulder_yaw")}
        <geom type="sphere" size="0.016" mass="0.02" material="shell"/>
        <body name="{arm_id}_upper" pos="{A.shoulder_offset} 0 0">
          <joint name="{arm_id}_shoulder_pitch" axis="0 -1 0" range="{r(A.shoulder_pitch_range)}"/>
          {bl(arm_id + "_shoulder_pitch", "0 -1 0")}
          {cad(arm_id + "_upper")}
          <geom type="capsule" fromto="0 0 0 {A.upper_len} 0 0" size="0.014" mass="{A.upper_mass}" material="shell"/>
          <body name="{arm_id}_fore" pos="{A.upper_len} 0 0">
            <joint name="{arm_id}_elbow" axis="0 0 {-s}" range="{r(A.elbow_range)}"/>
            {bl(arm_id + "_elbow", f"0 0 {-s}")}
            {cad(arm_id + "_fore")}
            {servo_box(arm_id + "_elbow")}
            <geom type="capsule" fromto="0 0 0 {A.fore_len} 0 0" size="0.015" mass="{A.fore_mass}" material="shell"/>
            <body name="{arm_id}_claw" pos="{A.fore_len} 0 0">
              {'<inertial pos="0 0 0" mass="0.0001" diaginertia="1e-8 1e-8 1e-8"/>' if USE_CAD else ''}
              <geom name="{arm_id}_palm" type="ellipsoid" pos="{palm_c:.4f} 0 0" size="0.026 0.020 0.017" mass="{A.claw_mass}" material="shell"/>
              <geom name="{arm_id}_pollex" type="box" pos="{hinge + jaw_h:.4f} {-s*0.009} 0" size="{jaw_h:.4f} 0.006 0.011" mass="0.004" material="claw"/>
              <site name="{arm_id}_grip_site" pos="{hinge + jaw_h:.4f} 0 0" size="0.008" rgba="0 0 0 0"/>
              <body name="{arm_id}_dactyl" pos="{hinge:.4f} 0 0">
                <joint name="{arm_id}_claw" axis="0 0 {s}" range="{r(A.claw_range)}"/>
                {bl(arm_id + "_claw", f"0 0 {s}")}
                {cad(arm_id + "_dactyl")}
                <geom type="box" pos="{jaw_h:.4f} 0 0" size="{jaw_h:.4f} 0.005 0.009" mass="{A.jaw_mass}" material="claw"/>
              </body>
            </body>
          </body>
        </body>
      </body>"""


def eyes_xml() -> str:
    if USE_CAD:                      # the CAD top shell has its own eye stalks
        return ""
    out = []
    for s in (1, -1):
        base, top = (0.050, s * 0.024, 0.022), (0.066, s * 0.030, 0.058)
        out.append(f"""
      <geom class="visual" type="capsule" fromto="{f(*base, *top)}" size="0.0045" material="shell"/>
      <geom class="visual" type="sphere" pos="{f(*top)}" size="0.011" material="eye"/>
      <geom class="visual" type="sphere" pos="{f(top[0] + 0.008, top[1], top[2] + 0.002)}" size="0.0055" material="pupil"/>""")
    return "".join(out)


def build() -> str:
    S, B, L = P.servo, P.body, P.leg
    # Standing height: foot below the leg mount when in the STAND pose.
    fem, tib = STAND[JOINT_NAMES.index("FL_femur")], STAND[JOINT_NAMES.index("FL_tibia")]
    z0 = -(L.femur_len * np.sin(fem) + L.tibia_len * np.sin(fem + tib)) + L.foot_radius + 0.002

    cam_pos = (0.42, -0.50, 0.30)
    actuators = "\n".join(
        f'    <position name="{j}" joint="{j}" class="crab" inheritrange="1"/>' for j in JOINT_NAMES)
    foot_sensors = "\n".join(
        f'    <touch name="{lg}_foot_touch" site="{lg}_foot_site"/>' for lg in LEG_IDS)
    stand = f(*STAND)

    if USE_CAD:
        meshes = "\n".join(f'    <mesh name="{v["mesh"]}" file="{v["file"]}" scale="0.001 0.001 0.001"/>'
                           for items in VIS.values() for v in items)
        # belly (under-body battery cradle) + base plate as collision; shell / chassis visuals from CAD
        carapace = ('<geom name="carapace" type="box" pos="0 0 -0.0335" size="0.0245 0.0700 0.0112" material="shell"/>\n'
                    '      <geom name="base_plate" type="box" pos="0 0 -0.0102" size="0.060 0.090 0.0100" material="shell"/>')
        eye_cam = "0.067 0 0.011"
        prim_group = 3                # primitives hidden (still collide); CAD meshes are what you see
    else:
        meshes, eye_cam, prim_group = "", "0.076 0 0.03", 0
        carapace = f'<geom name="carapace" type="ellipsoid" size="{f(*B.half_size)}" mass="{B.mass}" material="shell"/>'

    return f"""<!-- AUTO-GENERATED by sim/build_model.py from crab/params.py{' + CAD (cad/build.py)' if USE_CAD else ''}. Do not edit by hand. -->
<mujoco model="robotic_crab">
  <compiler angle="radian" autolimits="true" meshdir="meshes"/>
  <option timestep="0.002" integrator="implicitfast"/>

  <visual>
    <global offwidth="1280" offheight="720" azimuth="120" elevation="-20"/>
    <headlight ambient="0.35 0.35 0.35" diffuse="0.6 0.6 0.6" specular="0.1 0.1 0.1"/>
    <quality shadowsize="4096"/>
  </visual>

  <default>
    <default class="crab">
      <!-- ST3215 measured model (Rhoban BAM m1): see hardware/ST3215_reference.md -->
      <joint armature="{S.armature:.5f}" damping="{S.damping:.4f}" frictionloss="{S.frictionloss:.4f}"/>
      <position kp="{S.kp:.3f}" kv="{S.kv}" forcerange="{-S.force_limit:.3f} {S.force_limit:.3f}"/>
      <!-- robot geoms collide with the floor only (self-collision off for v0) -->
      <geom contype="1" conaffinity="0" condim="3" friction="0.8 0.02 0.001" group="{prim_group}"/>
      <default class="visual">
        <geom contype="0" conaffinity="0" group="2" density="0"/>
      </default>
      <!-- gear play: passive joint in series with each servo (datasheet backlash <= 0.5 deg) -->
      <default class="backlash">
        <joint damping="0.01" armature="0.01" frictionloss="0" range="{-BACKLASH_RANGE:.5f} {BACKLASH_RANGE:.5f}"/>
      </default>
    </default>
  </default>

  <asset>
    <texture name="sky" type="skybox" builtin="gradient" rgb1="0.55 0.75 0.95" rgb2="0.95 0.97 1" width="256" height="256"/>
    <texture name="sand" type="2d" builtin="checker" rgb1="0.86 0.80 0.66" rgb2="0.80 0.74 0.60" width="512" height="512" mark="edge" markrgb="0.7 0.64 0.5"/>
    <material name="floor" texture="sand" texrepeat="8 8" reflectance="0.05"/>
    <material name="shell" rgba="0.90 0.33 0.20 1" specular="0.3" shininess="0.4"/>
    <material name="claw" rgba="0.75 0.22 0.15 1" specular="0.3"/>
    <material name="tip" rgba="0.25 0.18 0.15 1"/>
    <material name="servo" rgba="0.12 0.12 0.14 1"/>
    <material name="eye" rgba="0.97 0.97 0.95 1"/>
    <material name="pupil" rgba="0.05 0.05 0.08 1"/>
    <material name="printed" rgba="0.92 0.40 0.22 1" specular="0.25" shininess="0.3"/>
    <material name="horn" rgba="0.75 0.76 0.78 1" specular="0.6" shininess="0.8"/>
{meshes}
  </asset>

  <worldbody>
    <light pos="0.3 -0.3 1.5" dir="-0.2 0.2 -1" diffuse="0.7 0.7 0.7" castshadow="true"/>
    <geom name="floor" type="plane" size="0 0 0.05" material="floor" contype="0" conaffinity="1"/>

    <body name="body" pos="0 0 {z0:.4f}" childclass="crab">
      <freejoint name="root"/>
      <camera name="track" mode="trackcom" pos="{f(*cam_pos)}" xyaxes="{lookat_xyaxes(cam_pos, (0, 0, 0))}"/>
      <!-- forward-looking "eye" camera for the future vision brain -->
      <camera name="eye_cam" pos="{eye_cam}" xyaxes="0 -1 0 0 0 1" fovy="102"/>
      <site name="imu" pos="0 0 0" size="0.01" rgba="0 0 0 0"/>
      {cad("body")}
      {carapace}
      {eyes_xml()}
{"".join(leg_xml(lg) for lg in LEG_IDS)}
{"".join(arm_xml(a) for a in ARM_IDS)}
    </body>
  </worldbody>

  <actuator>
{actuators}
  </actuator>

  <sensor>
    <gyro name="imu_gyro" site="imu"/>
    <accelerometer name="imu_accel" site="imu"/>
    <framequat name="imu_quat" objtype="site" objname="imu"/>
{foot_sensors}
  </sensor>

  <keyframe>
    <key name="stand" qpos="0 0 {z0:.4f} 1 0 0 0 {f(*qpos_tree_order(STAND))}" ctrl="{stand}"/>
  </keyframe>
</mujoco>
"""


if __name__ == "__main__":
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(build(), encoding="utf-8")
    import mujoco
    m = mujoco.MjModel.from_xml_path(str(OUT))
    print(f"wrote {OUT.relative_to(ROOT)}  |  bodies={m.nbody} joints={m.njnt} "
          f"actuators={m.nu}  total mass={sum(m.body_mass):.3f} kg")
