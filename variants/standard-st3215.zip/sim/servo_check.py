"""Can a real ST3215 deliver what the simulator asked of it?

Two servo models disagree, so we check against both:

* Measured model (Rhoban BAM, what the sim runs): the actuator "force" is the
  voltage-driven torque kt*V/R; it saturates at vin*kt/R ~ 3.52 N*m. Saturating
  it means the drive voltage is maxed out -> PASS/FAIL criterion.
* Datasheet model: 1.91 N*m at standstill, falling linearly to 0 at the 5.45 rad/s
  no-load speed. We compute the motor's electromagnetic torque
  (actuator force - kt^2/R * speed) and report how often it exceeds that line
  -> reported as a WARNING margin (the pessimistic case).
"""

import numpy as np

from crab.params import PARAMS

S = PARAMS.servo
KE = S.kt ** 2 / S.resistance          # back-EMF torque per rad/s (~0.56)
DS_STALL, DS_NOLOAD = S.stall_torque, 5.45


class ServoMonitor:
    def __init__(self, nu):
        self.n = 0
        self.volt_sat = np.zeros(nu)     # steps at the measured model's voltage limit
        self.ds_over = np.zeros(nu)      # steps beyond the datasheet torque-speed line
        self.peak_motor = np.zeros(nu)   # peak electromagnetic torque
        self.peak_vel = np.zeros(nu)

    def update(self, actuator_force, actuator_velocity):
        f, w = np.asarray(actuator_force), np.asarray(actuator_velocity)
        tau_m = f - KE * w
        motoring = np.sign(tau_m) == np.sign(w)
        limit = DS_STALL * np.clip(1 - np.where(motoring, np.abs(w), 0.0) / DS_NOLOAD, 0, 1)
        self.n += 1
        self.volt_sat += np.abs(f) >= 0.98 * S.force_limit
        self.ds_over += np.abs(tau_m) > limit
        self.peak_motor = np.maximum(self.peak_motor, np.abs(tau_m))
        self.peak_vel = np.maximum(self.peak_vel, np.abs(w))

    @property
    def volt_sat_pct(self):
        return 100 * self.volt_sat.max() / max(self.n, 1)

    @property
    def ds_over_pct(self):
        return 100 * self.ds_over.max() / max(self.n, 1)

    def worst_joint(self):
        return int(np.argmax(self.peak_motor))
