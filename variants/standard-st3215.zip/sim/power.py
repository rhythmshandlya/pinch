"""Electrical power budget from simulation.

Servo current comes from the measured motor model: I = |tau_motor| / kt, with
tau_motor = actuator force - kt^2/R * speed (electromagnetic torque), plus each
servo's 6 mA idle draw. Back-driven (regenerating) phases are counted as draw,
which is conservative. Prints average / peak current per scenario and battery
runtime estimates.

    python sim/power.py
"""

import sys
from pathlib import Path

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from crab.emotes import EMOTES, STAND  # noqa: E402
from crab.gait import GAITS, Gait  # noqa: E402
from crab.params import PARAMS  # noqa: E402
from sim.servo_check import KE  # noqa: E402

MODEL = ROOT / "sim" / "models" / "crab.xml"
S = PARAMS.servo
IDLE_A = 0.006
PI_W = 9.0                 # Raspberry Pi 5 + camera, busy (W)
BUCK_EFF = 0.90
V_BATT = 7.4               # 2S LiPo nominal
USABLE = 0.80              # don't drain LiPo below ~20 %


def run(m, d, ctrl_fn, seconds):
    n = int(seconds / m.opt.timestep)
    cur = np.zeros(n)
    for i in range(n):
        d.ctrl[:] = ctrl_fn(i * m.opt.timestep)
        mujoco.mj_step(m, d)
        tau_m = d.actuator_force - KE * d.actuator_velocity
        cur[i] = np.sum(np.abs(tau_m) / S.kt) + m.nu * IDLE_A
    return cur


def main():
    m = mujoco.MjModel.from_xml_path(str(MODEL))
    d = mujoco.MjData(m)

    def fresh():
        mujoco.mj_resetDataKeyframe(m, d, m.key("stand").id)
        run(m, d, lambda t: STAND, 1.0)

    scen = {}
    fresh()
    scen["standing"] = run(m, d, lambda t: STAND, 5.0)
    fresh()
    scen["idle emote"] = run(m, d, EMOTES["idle"].target, 6.4)
    for name in ("wave", "happy", "angry"):
        fresh()
        scen[f"{name} emote"] = run(m, d, EMOTES[name].target, EMOTES[name].duration)
    for gname, cmd, label in (("trot", (0.08, 0, 0), "trot forward"), ("trot", (0, 0.10, 0), "trot sideways"),
                              ("crawl", (0.02, 0, 0), "crawl")):
        fresh()
        g = Gait(GAITS[gname], com_offset=np.array([0.015, 0.0]))
        scen[label] = run(m, d, lambda t, g=g, cmd=cmd: g.step(m.opt.timestep, cmd), 8.0)[1000:]

    print(f"Servo bus at {S.vin} V; Pi 5 + camera ~{PI_W:.0f} W; buck efficiency {BUCK_EFF:.0%}\n")
    print(f"{'scenario':15s} {'servo avg A':>11s} {'peak A':>7s} {'p99 A':>6s} {'battery avg A':>13s} "
          f"{'3300mAh':>8s} {'4200mAh':>8s}")
    rows = {}
    for k, c in scen.items():
        servo_w = c.mean() * S.vin
        batt_a = (servo_w + PI_W) / BUCK_EFF / V_BATT
        rt = lambda mah: USABLE * mah / 1000 / batt_a * 60  # noqa: E731
        rows[k] = (c.mean(), c.max(), np.percentile(c, 99), batt_a)
        print(f"{k:15s} {c.mean():11.2f} {c.max():7.2f} {np.percentile(c, 99):6.2f} {batt_a:13.2f} "
              f"{rt(3300):6.0f}min {rt(4200):6.0f}min")
    return rows


if __name__ == "__main__":
    main()
