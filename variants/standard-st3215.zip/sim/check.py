"""Headless sanity check: does the crab stand, survive every emote, and stay
within ST3215 torque limits? Also renders snapshots to docs/images/.

    python sim/check.py            # report + snapshots
    python sim/check.py --no-render
"""

import argparse
import sys
from pathlib import Path

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from crab.emotes import EMOTES, STAND  # noqa: E402
from crab.params import JOINT_NAMES, PARAMS  # noqa: E402
from sim.latency import DelayLine  # noqa: E402
from sim.servo_check import ServoMonitor  # noqa: E402

MODEL = ROOT / "sim" / "models" / "crab.xml"
IMG_DIR = ROOT / "docs" / "images"
STALL, SAFE = PARAMS.servo.stall_torque, PARAMS.servo.safe_torque


def tilt_deg(d):
    # angle between body z-axis and world z-axis
    zz = d.xmat[1].reshape(3, 3)[2, 2]
    return np.degrees(np.arccos(np.clip(zz, -1, 1)))


def run(m, d, ctrl_fn, seconds, snap_times=(), renderer=None, cam="track"):
    dt = m.opt.timestep
    n = int(seconds / dt)
    mon = ServoMonitor(m.nu)
    min_h, max_tilt, peak_cmd_v = 1e9, 0.0, 0.0
    snaps, snap_steps = [], {int(t / dt) for t in snap_times}
    prev = np.asarray(ctrl_fn(0.0), float)
    delay = DelayLine(PARAMS.servo.command_delay, dt, prev)
    for i in range(n):
        q = np.asarray(ctrl_fn(i * dt), float)
        peak_cmd_v = max(peak_cmd_v, np.abs(q - prev).max() / dt)
        prev = q
        d.ctrl[:] = delay(q)
        mujoco.mj_step(m, d)
        mon.update(d.actuator_force, d.actuator_velocity)
        min_h = min(min_h, d.xpos[1, 2])
        max_tilt = max(max_tilt, tilt_deg(d))
        if renderer is not None and i in snap_steps:
            renderer.update_scene(d, camera=cam)
            snaps.append(renderer.render().copy())
    return dict(mon=mon, min_h=min_h, max_tilt=max_tilt, cmd_v=peak_cmd_v, snaps=snaps)


def grid(images, cols):
    h, w, _ = images[0].shape
    rows = -(-len(images) // cols)
    out = np.full((rows * h, cols * w, 3), 255, np.uint8)
    for k, im in enumerate(images):
        r, c = divmod(k, cols)
        out[r * h:(r + 1) * h, c * w:(c + 1) * w] = im
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-render", action="store_true")
    args = ap.parse_args()

    m = mujoco.MjModel.from_xml_path(str(MODEL))
    d = mujoco.MjData(m)
    renderer = None if args.no_render else mujoco.Renderer(m, 360, 640)

    mujoco.mj_resetDataKeyframe(m, d, m.key("stand").id)
    stand = run(m, d, lambda t: STAND, 2.0)
    hold = np.abs(d.actuator_force)

    print(f"total mass {sum(m.body_mass):.2f} kg | stand height {d.xpos[1, 2]*100:.1f} cm "
          f"| tilt {tilt_deg(d):.1f} deg")
    print(f"\nHolding torque in STAND (stall {STALL} N*m, target < {SAFE}):")
    for leg in ["FL", "FR", "RL", "RR"]:
        vals = [hold[JOINT_NAMES.index(f"{leg}_{j}")] for j in ("coxa", "femur", "tibia")]
        print(f"  {leg}: coxa {vals[0]:.2f}  femur {vals[1]:.2f}  tibia {vals[2]:.2f}")

    vmax = PARAMS.servo.max_speed
    print("\n(motor = peak electromagnetic torque; vsat% = time at measured-model voltage limit;"
          " ds% = time beyond datasheet torque-speed line; cmd = peak commanded joint speed)")
    print(f"{'emote':8s} {'dur':>5s} {'min h':>7s} {'tilt':>8s} {'motor':>6s} {'worst joint':>16s} "
          f"{'vsat%':>5s} {'ds%':>5s} {'cmd r/s':>8s}  result   (limits: vsat/ds 3%, cmd {vmax} rad/s)")
    snaps_all, labels = [], []
    if renderer:
        renderer.update_scene(d, camera="track")
        snaps_all.append(renderer.render().copy())
        labels.append("stand")
    ok_all = True
    for name, emo in EMOTES.items():
        mujoco.mj_resetDataKeyframe(m, d, m.key("stand").id)
        run(m, d, lambda t: STAND, 1.0)
        dur = emo.duration if not emo.loop else 2 * emo.duration
        r = run(m, d, emo.target, dur + 0.8, snap_times=[dur * 0.45], renderer=renderer)
        mon = r["mon"]
        worst = mon.worst_joint()
        fell = r["max_tilt"] > 45 or r["min_h"] < 0.02
        # Emotes are slow, deliberate motions: hold them to the *datasheet* servo too.
        too_hard = mon.volt_sat_pct > 3 or mon.ds_over_pct > 3 or r["cmd_v"] > vmax
        ok_all &= not (fell or too_hard)
        status = "FELL" if fell else ("TOO FAST/STRONG" if too_hard else "ok")
        print(f"{name:8s} {dur:5.1f} {r['min_h']*100:6.1f}cm {r['max_tilt']:5.1f}deg {mon.peak_motor[worst]:6.2f} "
              f"{JOINT_NAMES[worst]:>16s} {mon.volt_sat_pct:5.1f} {mon.ds_over_pct:5.1f} {r['cmd_v']:8.2f}  {status}")
        snaps_all += r["snaps"]
        labels += [name] * len(r["snaps"])

    if renderer:
        from PIL import Image, ImageDraw
        IMG_DIR.mkdir(parents=True, exist_ok=True)
        tiles = []
        for im, lab in zip(snaps_all, labels):
            pil = Image.fromarray(im)
            ImageDraw.Draw(pil).text((12, 10), lab, fill=(20, 20, 20))
            tiles.append(np.asarray(pil))
        Image.fromarray(grid(tiles, 4)).save(IMG_DIR / "emotes.png")
        mujoco.mj_resetDataKeyframe(m, d, m.key("stand").id)
        run(m, d, lambda t: STAND, 1.0)
        big = mujoco.Renderer(m, 720, 1280)
        big.update_scene(d, camera="track")
        Image.fromarray(big.render()).save(IMG_DIR / "stand.png")
        big.update_scene(d, camera="eye_cam")
        Image.fromarray(big.render()).save(IMG_DIR / "eye_cam.png")
        print(f"\nsnapshots -> {IMG_DIR.relative_to(ROOT)}/ (stand.png, emotes.png, eye_cam.png)")

    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
