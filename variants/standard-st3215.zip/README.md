# Robotic Crab 🦀

A 4-legged robot crab with 2 claws, 20 servos and a vision-language brain. It's designed, simulated,
tested and made order-ready entirely in open-source software, before buying a single part.
Inspired by Pollen Robotics' Open Duck Mini. Parts come from robu.in, printed parts from robu.in's print service.

![stand](docs/images/stand.png)

## Status: order-ready (Phase A done)

| | What | Where | Verified by |
|---|---|---|---|
| ✅ | Parametric robot (all dimensions in one file) | [crab/params.py](crab/params.py) | |
| ✅ | **Measured servo model** (Rhoban BAM, ST3215) plus 5 ms bus latency | [hardware/ST3215_reference.md](hardware/ST3215_reference.md) | |
| ✅ | 6 emotes: idle, wave, angry, happy, shy, sleep | [crab/emotes.py](crab/emotes.py) | `sim/check.py`: within torque and speed limits under **both** the measured and datasheet servo models |
| ✅ | Scripted walking: trot (main) and crawl (sneak), any direction | [crab/gait.py](crab/gait.py) | `sim/walk.py`: 6 directions × 2 gaits pass |
| ✅ | **Full CAD**: 10 printable parts (26 pieces), STL + STEP | [cad/](cad/), [cad/out/print/](cad/out/print) | `cad/check.py`: print rules, servo fit, **100/100 poses collision-free** |
| ✅ | Simulator built from the CAD (meshes, real masses and inertia: 2.02 kg) | [sim/build_model.py](sim/build_model.py) | |
| ✅ | Joint limits from CAD interference (bisection) | [cad/limits.py](cad/limits.py) | |
| ✅ | Electronics: block diagram, wiring, simulated power budget, ID map | [hardware/electronics.md](hardware/electronics.md) | `sim/power.py` |
| ✅ | Robot runtime for the Raspberry Pi: servo bus, calibration, safety, emotes, gait, policy | [robot/](robot/) | `robot/selftest.py`: 10/10 against simulated hardware |
| ✅ | RL training pipeline (MJX + Brax PPO) and Colab notebook | [training/](training/) | CPU smoke test trains and saves; the policy runs through `sim/walk.py --policy` |
| ✅ | Brain v0: Gemma 4 via Ollama, sees through the eye camera, picks safe actions | [brain/](brain/) | Full loop tested with the stand-in brain; real model needs `ollama pull gemma4:e4b` |
| ✅ | **One robu.in order**: parts + tools ≈ ₹85.6k (+ printing ≈ ₹3.5-6k) | [hardware/BOM.md](hardware/BOM.md) | |
| ✅ | Beginner assembly guide | [hardware/ASSEMBLY.md](hardware/ASSEMBLY.md) | |
| ⏳ | GPU training run (Colab), then the physical build | [docs/ROADMAP.md](docs/ROADMAP.md) | |

![trot](docs/images/walk_trot.gif)

## Quick start (Windows, PowerShell)

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt build123d
.venv\Scripts\python cad\build.py            # CAD -> print STLs, sim meshes, mass properties
.venv\Scripts\python sim\build_model.py      # params + CAD -> sim/models/crab.xml
.venv\Scripts\python sim\walk.py --view      # watch it walk (forward, crab-walk, turn)
.venv\Scripts\python sim\view.py             # watch the emotes
.venv\Scripts\python robot\run.py --sim      # the Raspberry Pi program, driving the simulator
```

Tests:

```powershell
.venv\Scripts\python sim\check.py            # emotes vs servo limits (+ renders)
.venv\Scripts\python sim\walk.py             # walking, both gaits, all directions
.venv\Scripts\python cad\check.py            # print rules, servo fit, self-collision sweep (~4 min)
.venv\Scripts\python robot\selftest.py       # robot software against simulated hardware
.venv\Scripts\python sim\power.py            # current draw and battery runtime
```

RL (separate environment, pinned versions):

```powershell
python -m venv .venv-rl
.venv-rl\Scripts\python -m pip install -r requirements-train.txt
.venv-rl\Scripts\python training\train.py --preset smoke     # proves the pipeline on CPU
.venv\Scripts\python training\make_colab_bundle.py          # then train for real in training/colab_train.ipynb
```

## How the pieces fit

```
crab/params.py ──► cad/ (build123d) ──► STL/STEP for printing
      │                 │
      │                 └──► meshes + masses ──► sim/models/crab.xml (MuJoCo)
      │                                              │
      ├──► crab/kinematics, gait, emotes ────────────┤──► sim tests, viewer, GIFs
      ├──► crab/policy_io (obs/action contract) ─────┤──► training/ (MJX + PPO, Colab)
      └──► robot/ (Raspberry Pi runtime) ◄───────────┘    brain/ (Gemma 4 via Ollama)
              ├─ RealBackend: rustypot + FE-URT-1, BNO055, Pi camera
              └─ SimBackend: the same code, driving MuJoCo
```

## Design decisions the simulator forced

* **Claws pull the centre of mass forward**, so the legs sit 1.5 cm forward of the body centre.
* **The measured motor model** (back-EMF) showed fast moves lose torque. The trot cycle went to 0.9 s, and two emotes were slowed.
* **Servo voltage**: the 7.4 V servo vs an 8.4 V full LiPo, so a 20 A buck regulator caps it.
* **Driver board**: the cheap Waveshare board needs 9-12.6 V input, so it was swapped for Feetech's FE-URT-1 signal converter.
* **CAD collisions**: the arms hit the front legs and the claws crossed, so the mounts moved and the joint limits came from bisection.
* **Battery** (135 mm) doesn't fit between the hip servos, so it sits under the body (lower centre of mass, easy swaps).

## Known limitations

* Two servo data sources disagree on torque: the datasheet says 1.91 N·m, the BAM measurement 3.5 N·m. Tests check both, and RL trains across the range. Full-speed sideways trot exceeds the pessimistic datasheet curve about 5% of the time.
* `RealBackend` and `setup_servo.py` follow rustypot's documented API but couldn't be run without hardware. Check the method names on the Pi.
* Self-collision is off in the physics sim. It's covered by the CAD sweep, and the joint limits come from it.
* Crawl is slow (~2 cm/s) by design; trot is the everyday gait, and RL should beat both.
* The brain needs Ollama plus a Gemma 4 model (e4b ≈ 6.6 GB) on the PC; not installed yet.
* At rest, the upper arms frame the sides of the eye camera's view and the centre stays clear
  ([docs/images/eye_cam.png](docs/images/eye_cam.png)). Raising the claws clears it.
