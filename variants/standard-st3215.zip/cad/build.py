"""Export everything the CAD produces.

    python cad/build.py

  cad/out/print/<part>.stl + .step   files for the robu.in print service (one per unique part)
  cad/out/print_sheet.csv            part, qty, material, infill, size, est. mass
  sim/models/meshes/*.stl            per-component meshes in each simulator body's frame (mm)
  sim/models/mass_props.json         mass / centre of mass / inertia per simulator body
  sim/models/visuals.json            which mesh goes on which body, with a material

Then run `python sim/build_model.py` (it picks these up automatically).
"""

import csv
import json
import re
import sys
from pathlib import Path

from build123d import export_step, export_stl

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from cad import assembly as A  # noqa: E402

OUT = ROOT / "cad" / "out"
PRINT = OUT / "print"
MESH_DIR = ROOT / "sim" / "models" / "meshes"

INFILL = {"chassis": "40% gyroid, 4 walls", "top_shell": "solid (2 mm wall), 3 walls",
          "foot_tip": "TPU 95A, 50% gyroid", "default": "50% gyroid, 4 walls"}
ORIENT = {"chassis": "base plate down", "top_shell": "skirt down (supports under eye stalks)",
          "coxa_link": "horn plate down", "femur_link": "thick cradle side down",
          "tibia": "horn plate side down", "foot_tip": "sphere up", "upper_arm": "horn plate down",
          "forearm": "horn plate up, supports under the drop", "dactyl_L": "jaw down", "dactyl_R": "jaw down"}


def material_of(label):
    if "servo" in label:
        return "servo"
    if "horn" in label:
        return "horn"
    if "foot" in label:
        return "tip"
    if label in ("top_shell",):
        return "shell"
    if "dactyl" in label or "forearm" in label:
        return "claw"
    return "printed"


def main():
    PRINT.mkdir(parents=True, exist_ok=True)
    MESH_DIR.mkdir(parents=True, exist_ok=True)

    # 1. print files + sheet
    rows = []
    for name, (_, rho, fill, mat, qty) in A.PRINTED.items():
        p = A.part(name)
        export_stl(p, str(PRINT / f"{name}.stl"), tolerance=0.02, angular_tolerance=0.1)
        export_step(p, str(PRINT / f"{name}.step"))
        bb = p.bounding_box()
        rows.append(dict(part=name, qty=qty, material=mat, infill=INFILL.get(name, INFILL["default"]),
                         orientation=ORIENT.get(name, ""),
                         size_mm=f"{bb.size.X:.0f} x {bb.size.Y:.0f} x {bb.size.Z:.0f}",
                         est_mass_g=round(A.part_mass(name) * 1000, 1),
                         volume_cm3=round(p.volume / 1000, 1)))
    with open(OUT / "print_sheet.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f"print files -> {PRINT.relative_to(ROOT)} ({len(rows)} unique parts, "
          f"{sum(r['qty'] for r in rows)} pieces)")

    # 2. simulator meshes (coarser tessellation is plenty for visuals)
    visuals = {}
    for body, items in A.groups().items():
        visuals[body] = []
        for label, solid, _ in items:
            fname = re.sub(r"[^a-zA-Z0-9]+", "_", f"{body}__{label}").strip("_") + ".stl"
            export_stl(solid, str(MESH_DIR / fname), tolerance=0.15, angular_tolerance=0.3)
            visuals[body].append(dict(mesh=fname[:-4], file=fname, material=material_of(label)))
    (ROOT / "sim" / "models" / "visuals.json").write_text(json.dumps(visuals, indent=1))
    print(f"sim meshes  -> {MESH_DIR.relative_to(ROOT)} ({sum(len(v) for v in visuals.values())} files)")

    # 3. mass properties
    mp = A.mass_properties()
    (ROOT / "sim" / "models" / "mass_props.json").write_text(json.dumps(mp, indent=1))
    print(f"mass props  -> sim/models/mass_props.json (robot total {sum(v['mass'] for v in mp.values()):.3f} kg)")


if __name__ == "__main__":
    main()
