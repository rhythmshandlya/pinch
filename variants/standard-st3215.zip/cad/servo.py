"""ST3215-7.4V / STS3215 envelope and hole positions (mm). Source: hardware/ST3215_reference.md.

Servo frame: output shaft = +Z (horn on +Z face), case length along X with the
output end at +X (shaft is 10.11 mm from it), Y across the 24.7 mm width,
Z = 0 is the servo mid-plane (case main faces at Z = +-16).
"""

from math import cos, radians, sin

from build123d import Align, Box, Cylinder, Pos

CASE_L, CASE_W, CASE_T = 45.2, 24.7, 32.0
X_OUT = 10.11                      # shaft -> output end
X_REAR = -(CASE_L - X_OUT)         # shaft -> rear end (-35.09)
HALF_W = CASE_W / 2                # 12.35
FACE = CASE_T / 2                  # 16.0, main case faces
HORN_R = 9.6                       # horn disc radius (dia 19.2)
HORN_FACE = 18.625                 # horn outer face (37.25 mm over both horns)
HORN_INNER = 16.1
HORN_PCD_R = 7.0                   # 4 x M3 on dia 14
HORN_SWEEP_R = 10.2                # keep plates on the case faces outside this radius (horn 9.6 + 0.6)
BOSS_R, BOSS_TOP = 3.0, 18.6       # idler boss (dia 6), protrudes to |z| = 18.6
CASE_HOLES = [(-8.3, 10.25), (-8.3, -10.25), (-29.0, 10.25), (-29.0, -10.25)]  # M2, both faces

M2_CLEAR, M2_PILOT = 2.4, 1.6
M3_CLEAR, M3_INSERT = 3.4, 4.2     # clearance / brass heat-set insert hole
FIT = 0.25                         # clearance around servo cases (robu.in: +-0.2 mm)


def case():
    """Servo case as a solid (for clearance / interference checks and rendering)."""
    body = Pos((X_OUT + X_REAR) / 2, 0, 0) * Box(CASE_L, CASE_W, CASE_T)
    boss = Pos(0, 0, -FACE - (BOSS_TOP - FACE) / 2) * Cylinder(BOSS_R, BOSS_TOP - FACE)
    return body + boss


def horn():
    """Output horn (+Z face). Rotates with the child link."""
    return Pos(0, 0, (HORN_INNER + HORN_FACE) / 2) * Cylinder(HORN_R, HORN_FACE - HORN_INNER)


def horn_hole_xy():
    return [(HORN_PCD_R * cos(radians(a)), HORN_PCD_R * sin(radians(a))) for a in (45, 135, 225, 315)]


def disc(r, z0, z1, x=0.0, y=0.0):
    """Cylinder along Z between z0 and z1."""
    return Pos(x, y, (z0 + z1) / 2) * Cylinder(r, abs(z1 - z0))


def box(x0, x1, y0, y1, z0, z1):
    """Axis-aligned box from min/max corners."""
    return Pos((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2) * Box(abs(x1 - x0), abs(y1 - y0), abs(z1 - z0),
                                                                  align=(Align.CENTER,) * 3)
