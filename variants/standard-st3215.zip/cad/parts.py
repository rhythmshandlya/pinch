"""Printable parts of the crab, built with build123d (open-source code-CAD). Units: mm.

Every part is built in the frame of the simulator body it belongs to
(see sim/build_model.py), so the same geometry drives the STL for printing,
the meshes/masses in the simulator and the interference checks.

Design rules (robu.in FDM service: walls >= 1 mm, +-0.2 mm accuracy):
  * plates >= 2.2 mm, horn plates 3 mm
  * 0.25 mm clearance around servo cases
  * links attach to the servo's output horn on one side (4 x M3 on dia 14);
    the next servo sits in a cradle screwed to its case (M2 self-tapping)
  * consecutive links live in different "layers" (horn layer |y| >= 18.625 vs
    cradle layer |y| <= 18.2), so a joint can't hit its neighbour however it turns
  * links are symmetric about their own mid-plane -> left and right sides use
    the same printed part (the servo is just mounted flipped). Only the moving
    claw jaw (dactyl) comes in L/R versions.
"""

import sys
from math import cos, radians, sin
from pathlib import Path

from build123d import (Circle, Cylinder, Ellipse, Plane, Polygon, Pos, Rectangle, Rot, Sphere, extrude, mirror,
                       offset)
from build123d import scale as b3d_scale

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from cad.servo import (BOSS_R, CASE_HOLES, CASE_W, FACE, FIT, HALF_W, HORN_FACE,  # noqa: E402
                       HORN_SWEEP_R, M2_CLEAR, M3_CLEAR, M3_INSERT, X_OUT, X_REAR,
                       box, disc, horn_hole_xy)
from crab.params import PARAMS  # noqa: E402

MM = 1000.0
LC = PARAMS.leg.coxa_len * MM          # 32  yaw -> femur axis
LF = PARAMS.leg.femur_len * MM         # 70  femur -> knee axis
LT = PARAMS.leg.tibia_len * MM         # 100 knee -> foot centre
FOOT_R = PARAMS.leg.foot_radius * MM   # 9
LS = PARAMS.arm.shoulder_offset * MM   # 32
LU = PARAMS.arm.upper_len * MM         # 55  shoulder pitch -> elbow axis
K_AXIS = (PARAMS.arm.fore_len + 0.5 * PARAMS.arm.claw_len) * MM   # 80 elbow -> claw servo axis

PLATE, SIDE = 3.0, 2.2
CW = HALF_W + 1.25                    # half-width of cradle plates on z-facing servo faces (13.6)
H0, H1 = HORN_FACE, HORN_FACE + PLATE  # horn plate layer (18.625 .. 21.625)
C0, C1 = FACE, FACE + SIDE             # cradle layer on a case face (16 .. 18.2)


# ---------------------------------------------------------------- helpers
def cyl_y(r, y0, y1, x, z):
    return Pos(x, (y0 + y1) / 2, z) * Rot(90, 0, 0) * Cylinder(r, abs(y1 - y0))


def cyl_x(r, x0, x1, y, z):
    return Pos((x0 + x1) / 2, y, z) * Rot(0, 90, 0) * Cylinder(r, abs(x1 - x0))


def horn_holes_y(sign):
    """M3 clearance + centre access holes through a horn plate lying in the y-layer."""
    y0, y1 = (H0 - 1, H1 + 1) if sign > 0 else (-H1 - 1, -H0 + 1)
    cut = cyl_y(3.5, y0, y1, 0, 0)
    for a, b in horn_hole_xy():
        cut += cyl_y(M3_CLEAR / 2, y0, y1, a, b)
    return cut


def horn_holes_z(sign=1):
    z0, z1 = (H0 - 1, H1 + 1) if sign > 0 else (-H1 - 1, -H0 + 1)
    cut = disc(3.5, z0, z1)
    for a, b in horn_hole_xy():
        cut += disc(M3_CLEAR / 2, z0, z1, a, b)
    return cut


def sorted2(a, b):
    return (a, b) if a <= b else (b, a)


# ---------------------------------------------------------------- legs
def coxa_link():
    """Hip bracket: bolts to the yaw servo's top horn, cradles the femur servo (case hanging down).
    Frame: yaw axis at origin, x radial out, z up. Femur axis at (LC, 0, 0) along y.
    Also used as the arm's shoulder bracket (LS == LC)."""
    br0, br1 = LC - HALF_W - 3.25, LC - HALF_W - FIT       # rear bridge, clears the yaw servo when turning
    xf1 = LC + HALF_W + 1.0                                 # >= 1.6 mm of plastic beyond the outer screw holes
    zb = X_REAR - FIT                                       # femur servo rear end (hangs down)
    p = disc(12, H0, H1) + box(0, br1, -C1, C1, H0, H1)     # plate on the yaw servo's horn
    p += box(br0, br1, -C1, C1, zb - PLATE, H1)             # rear bridge, down to below the femur servo
    p += box(br0, xf1, -C1, C1, zb - PLATE, zb)             # floor under the femur servo
    for s in (1, -1):                                       # cradle plates on both case faces; they run up
        plate = box(br0, xf1, *sorted2(s * C0, s * C1), zb - PLATE, HORN_SWEEP_R + 2.3)   # past the horn
        p += plate - cyl_y(HORN_SWEEP_R, -30, 30, LC, 0)   # so it leaves a ring, not knife edges
    p -= horn_holes_z(+1)
    for xs, ys in CASE_HOLES:                               # femur servo: x_s = +z, y_s = +x
        p -= cyl_y(M2_CLEAR / 2, -25, 25, LC + ys, xs)
    return p


def femur_link():
    """Thigh: bolts to the femur servo horn (+y), cradles the knee servo (case toward the hip,
    horn on -y). Frame: femur axis at origin, x along the femur."""
    xt0, xt1 = LF + X_REAR - FIT, LF + X_OUT                # knee servo case span
    xb0 = xt0 - PLATE
    zi, zo = HALF_W + FIT, HALF_W + FIT + 2.5
    p = cyl_y(12, H0, H1, 0, 0) + box(0, xb0 + 1, H0, H1, -10, 10)     # horn plate + arm
    p += box(xb0, xt1, C0, H1, -zo, zo)                                 # thick cradle, idler side
    p += box(xb0, xt1, -C1, -C0, -zo, zo) - cyl_y(HORN_SWEEP_R, -30, 0, LF, 0)
    p += box(xb0, xt0, -C1, H1, -zo, zo)                                # rear bridge
    for s in (1, -1):                                                   # top / bottom webs
        p += box(xb0, xt1, -C1, H1, *sorted2(s * zi, s * zo))
    p -= horn_holes_y(+1)
    p -= cyl_y(BOSS_R + 1, C0 - 1, H1 + 1, LF, 0)                       # knee servo idler boss
    for xs, ys in CASE_HOLES:                                           # knee servo: x_s = +x, y_s = +z
        p -= cyl_y(M2_CLEAR / 2, -30, 30, LF + xs, ys)
        p -= cyl_y(2.2, H1 - 2.5, H1 + 1, LF + xs, ys)                  # counterbore (M2x8 screws)
    return p


def tibia():
    """Shin: bolts to the knee servo horn (-y layer), jogs to the leg centre-plane, ends in the foot.
    Frame: knee axis at origin, x along the shin."""
    p = cyl_y(12, -H1, -H0, 0, 0) + box(0, 50, -H1, -H0, -8, 8)
    p += box(44, 52, -H1, 5, -8, 8)                         # jog toward the centre-plane
    p += box(48, LT - 3, -5, 5, -7, 7)                      # shin beam (foot tip slides over the end)
    p -= horn_holes_y(-1)
    p -= cyl_x(1.0, LT - 20, LT, 0, 0)                      # weight-saving core
    p -= Pos(LT - 10, 0, 0) * Cylinder(M3_CLEAR / 2, 20)    # cross hole for the foot-tip screw
    return p


def foot_tip():
    """TPU foot: soft sphere at the shin end. Frame: tibia frame."""
    tip = Pos(LT, 0, 0) * Sphere(FOOT_R)
    tip += box(LT - 16, LT - 2, -7.2, 7.2, -9.2, 9.2)
    tip -= box(LT - 17, LT - 3 + 0.2, -5 - FIT, 5 + FIT, -7 - FIT, 7 + FIT)
    tip -= Pos(LT - 10, 0, 0) * Cylinder(M3_CLEAR / 2, 30)
    return tip


# ---------------------------------------------------------------- arms
def upper_arm():
    """Upper arm: bolts to the shoulder-pitch horn (+y layer), cradles the elbow servo
    (shaft along z, case pointing forward). Frame: pitch axis at origin, x along the arm."""
    xe0, xe1 = LU - X_OUT - FIT, LU - X_REAR + FIT          # elbow servo case span (output end first)
    p = cyl_y(12, H0, H1, 0, 0) + box(0, xe0, H0, H1, -10, 10)
    p += box(xe0 - PLATE, xe0, -HALF_W, H1, -C1, C1)        # bridge at the servo's output end
    for s in (1, -1):                                       # cradles wider than the case: no thin strips
        p += box(xe0 - PLATE, xe1, -CW, CW, *sorted2(s * C0, s * C1)) - disc(HORN_SWEEP_R, -30, 30, LU, 0)
    p += box(xe1, xe1 + PLATE, -HALF_W, HALF_W, -C1, C1)    # front bridge
    p -= horn_holes_y(+1)
    for xs, ys in CASE_HOLES:                               # elbow servo: x_s = -x, y_s = -y
        p -= disc(M2_CLEAR / 2, -30, 30, LU - xs, -ys)
    return p


def forearm():
    """Forearm + palm + fixed jaw (pollex): bolts to the elbow horn (top layer), drops to the
    claw plane, cradles the claw servo (shaft along z). Symmetric in y.
    Frame: elbow axis at origin, x along the forearm."""
    xk0, xk1 = K_AXIS + X_REAR - FIT, K_AXIS + X_OUT
    p = disc(12, H0, H1) + box(0, xk0, -10, 10, H0, H1)
    p += box(xk0 - PLATE, xk0, -HALF_W, HALF_W, -C1, H1)    # drop down to the claw servo
    xf = xk1 + FIT
    for s in (1, -1):                                       # cradles run on over the front bridge
        p += box(xk0 - PLATE, xf + PLATE, -CW, CW, *sorted2(s * C0, s * C1)) - \
            disc(HORN_SWEEP_R, -30, 30, K_AXIS, 0)
    p += box(xf, xf + PLATE, -HALF_W, HALF_W, -C1, 6)       # front bridge
    tip = K_AXIS + 52                                       # fixed jaw, centred, pointed
    jaw = Pos(0, 0, -6) * extrude(Polygon((xf, -5), (tip - 8, -5), (tip, -1), (tip, 1), (tip - 8, 5), (xf, 5),
                                          align=None), 12)
    for i in range(4):                                       # teeth on both gripping faces (not on the tip)
        x = K_AXIS + 21 + 5.5 * i
        jaw -= box(x, x + 2.5, 4.2, 6, -7, 7) + box(x, x + 2.5, -6, -4.2, -7, 7)
    p += jaw
    p -= horn_holes_z(+1)
    for xs, ys in CASE_HOLES:                               # claw servo: servo frame = forearm frame
        p -= disc(M2_CLEAR / 2, -30, 30, K_AXIS + xs, ys)
    return p


def dactyl(side=1):
    """Moving claw jaw: bolts to the claw servo horn (top), drops to the claw plane beside
    the fixed jaw. Frame: claw servo axis at origin. side=+1 left arm, -1 right (mirror)."""
    p = disc(12, H0, H1) + box(0, 24, -4, 13, H0, H1)
    p += box(20, 24, 5.3, 13, -6, H1)                       # drop (radius > 20.7: clears the palm bridge)
    jaw = Pos(0, 0, -6) * extrude(Polygon((20, 5.3), (52, 5.3), (52, 7.5), (44, 12.3), (20, 12.3),
                                          align=None), 12)
    for i in range(4):                                       # teeth stop before the narrow tip
        x = 26.75 + 5.5 * i
        jaw -= box(x, x + 2.5, 5.0, 6.1, -7, 7)
    p += jaw
    p -= horn_holes_z(+1)
    return p if side > 0 else mirror(p, about=Plane.XZ)


# ---------------------------------------------------------------- body
def yaw_mounts():
    """(name, x, y, yaw_deg) of the 6 yaw servos in the body frame (mm), right side mirrored."""
    out = []
    for lg in ("FL", "FR", "RL", "RR"):
        (x, y, z), yaw = PARAMS.leg_mounts[lg[0]]
        s = 1 if lg[1] == "L" else -1
        out.append((lg, x * MM, s * y * MM, s * yaw * 180 / 3.141592653589793))
    (x, y, z), yaw = PARAMS.arm_mount
    for a, s in (("L", 1), ("R", -1)):
        out.append((a, x * MM, s * y * MM, s * yaw * 180 / 3.141592653589793))
    return out


BATTERY = (135.0, 44.0, 22.0)      # Bonka 2S 3300 mAh 25C (robu.in 1891446): 135 x 44 mm, 190 g; height assumed 22
BELLY_Z = -20.25 - BATTERY[2] - 2 * FIT - 2.0   # bottom of the under-body battery cradle
PI_HOLES = (49.0, 58.0)            # Raspberry Pi 5 hole rectangle (x, y)
BASE_Z0, BASE_Z1 = -20.25, -16.25  # base plate (servo case bottoms at -16)
CAMERA_Z = 11.0                    # camera window height (sim eye_cam sits here too)


SHELL_BOSSES = [(34.0, 0.0), (-60.0, 0.0)]   # clear of camera tunnel, battery, Pi, brackets; screws from below


# ---- top-view (2D) outlines, computed with Shapely so "opening" (removing slivers) is robust
def _xf(pts, x, y, yaw_deg):
    c, s = cos(radians(yaw_deg)), sin(radians(yaw_deg))
    return [(x + c * px - s * py, y + s * px + c * py) for px, py in pts]


def _yaw_range_deg(name):
    """Angles (deg, in the mount's own frame) a hip / shoulder bracket can swing through.
    Uses the CAD-checked joint ranges; the sign follows each joint's axis (see build_model)."""
    from math import degrees
    if name in ("L", "R"):
        lo, hi = PARAMS.arm.shoulder_yaw_range
        s = 1 if name == "L" else -1           # arm yaw axis is +z on the left, -z on the right
    else:
        lo, hi = PARAMS.leg.coxa_range_for(name)
        s = -1 if name[1] == "L" else 1        # coxa axis is -z on the left, +z on the right
    a, b = sorted((s * degrees(lo), s * degrees(hi)))
    return a, b


def keepouts2d(kind="chassis", margin=1.5):
    """Top view of what the hip / shoulder brackets (and what they carry) sweep through,
    computed exactly: the footprint rotated through the joint range, plus a margin.

    kind="chassis": only parts below the body's top plane (rear bridge, cradle, hanging servo)
    kind="shell":   everything above it too (horn plate, femur/upper link)"""
    from shapely.affinity import rotate, translate
    from shapely.geometry import box as sbox
    from shapely.ops import unary_union
    br0 = LC - HALF_W - 3.25
    if kind == "chassis":
        foot = sbox(br0, -C1, LC + HALF_W + 1.0, C1)
    else:
        foot = sbox(-12.0, -C1 - 3.5, LC + 70.0, C1 + 3.5)
    parts = []
    for name, x, y, yaw in yaw_mounts():
        a, b = _yaw_range_deg(name)
        steps = max(2, int((b - a) / 3) + 1)
        for k in range(steps):
            ang = yaw + a + (b - a) * k / (steps - 1)
            parts.append(translate(rotate(foot, ang, origin=(0, 0)), x, y))
    return unary_union(parts).buffer(margin, 16)


def _pockets2d(grow):
    from shapely.geometry import Polygon as SPoly
    from shapely.ops import unary_union
    x0, x1, h = X_REAR - grow, X_OUT + grow, HALF_W + grow
    return unary_union([SPoly(_xf([(x0, -h), (x1, -h), (x1, h), (x0, h)], x, y, yaw))
                        for _, x, y, yaw in yaw_mounts()])


def _ellipse2d(a, b, n=240):
    from shapely.geometry import Polygon as SPoly
    return SPoly([(a * cos(2 * 3.141592653589793 * k / n), b * sin(2 * 3.141592653589793 * k / n)) for k in range(n)])


def opened(geom, r=1.0):
    """Morphological opening: removes any feature narrower than 2r, keeps the largest piece."""
    g = geom.buffer(-r, 16).buffer(r, 16)
    return max(getattr(g, "geoms", [g]), key=lambda p: p.area)


def to_face(poly):
    """Shapely polygon (with holes) -> build123d face, counter-clockwise so it extrudes upward."""
    from shapely.geometry.polygon import orient
    poly = orient(poly, sign=1.0)
    f = Polygon(*list(poly.exterior.coords)[:-1], align=None)
    for ring in poly.interiors:
        f -= Polygon(*list(ring.coords)[:-1], align=None)
    return f


def _sector(r_in, r_out, half_angle, z0, z1):
    pts = [(0, 0)] + [(2 * r_out * cos(radians(a)), 2 * r_out * sin(radians(a)))
                      for a in range(-half_angle, half_angle + 1, 10)]
    wedge = Pos(0, 0, z0) * extrude(Polygon(*pts, align=None), z1 - z0)
    return (disc(r_out, z0, z1) & wedge) - disc(r_in, z0 - 1, z1 + 1)


def keepouts(z0=-60, z1=60):
    """Regions the hip / shoulder brackets sweep through; the body must stay out of them."""
    k = None
    for _, x, y, yaw in yaw_mounts():
        s = Pos(x, y, 0) * Rot(0, 0, yaw) * _sector(LC - HALF_W - 3.25 - 0.8, 75, 120, z0, z1)
        k = s if k is None else k + s
    return k


def _servo_pockets(grow, x_max=None):
    out = None
    for _, x, y, yaw in yaw_mounts():
        x1 = X_OUT + grow if x_max is None else x_max
        b = Pos(x, y, 0) * Rot(0, 0, yaw) * box(X_REAR - grow, x1, -HALF_W - grow, HALF_W + grow,
                                                 -FACE - grow, FACE + grow)
        out = b if out is None else out + b
    return out


def _servo_case_bottom_holes():
    cut = None
    for _, x, y, yaw in yaw_mounts():
        loc = Pos(x, y, 0) * Rot(0, 0, yaw)
        c = loc * disc(BOSS_R + 1, BASE_Z0 - 1, BASE_Z1 + 1)
        for xs, ys in CASE_HOLES:
            c += loc * disc(M2_CLEAR / 2, BASE_Z0 - 1, BASE_Z1 + 1, xs, ys)
            c += loc * disc(2.2, BASE_Z0 - 1, BASE_Z0 + 1.5, xs, ys)      # screw head counterbore
        cut = c if cut is None else cut + c
    return cut


def chassis():
    """Body tub: holds the 6 yaw servos, battery, Raspberry Pi, servo driver and regulator."""
    # base plate: top-view outline = oval + servo footprints - bracket sweep zones, then
    # "opened" so no sliver thinner than 2 mm survives the cuts
    outline = opened(_ellipse2d(68, 98).union(_pockets2d(3.0)).difference(keepouts2d()), 1.0)
    base = Pos(0, 0, BASE_Z0) * extrude(to_face(outline), BASE_Z1 - BASE_Z0)
    # pocket walls around the inner 2/3 of each servo (clear of the bracket sweep: no slivers)
    walls = (_servo_pockets(3.0, x_max=-10.0) - _servo_pockets(FIT)) & box(-200, 200, -200, 200, BASE_Z1, 0.0)
    body = base + walls
    # battery cradle UNDER the base plate (lowers the centre of mass; strap from below)
    bx, by = BATTERY[1] + 2 * FIT, BATTERY[0] + 2 * FIT
    cradle = box(-bx / 2 - 2, bx / 2 + 2, -by / 2 - 2, by / 2 + 2, BELLY_Z, BASE_Z0) - \
        box(-bx / 2, bx / 2, -by / 2, by / 2, BELLY_Z - 1, BASE_Z0 + 0.5)
    for yy in (-35, 35):                                   # slots for a hook-and-loop strap
        cradle -= box(-bx / 2 - 3, bx / 2 + 3, yy - 10, yy + 10, BELLY_Z - 1, BELLY_Z + 4)
    body += cradle
    body -= box(-12, 12, -by / 2 + 10, by / 2 - 10, BASE_Z0 - 1, BASE_Z1 + 1)   # cable pass-through
    # Raspberry Pi standoffs (board at z = -6), M2.5 heat-set inserts
    px, py = PI_HOLES[0] / 2, PI_HOLES[1] / 2
    for sx in (-1, 1):
        for sy in (-1, 1):
            body += disc(3.7, BASE_Z1, -6.0, sx * px, sy * py) - disc(1.8, -12, -5, sx * px, sy * py)
    # rear electronics deck posts (servo driver board + 7.4 V regulator), M3 inserts
    for x in (-34.0, -58.0):
        for y in (-18.0, 18.0):
            body += disc(4.0, BASE_Z1, BASE_Z1 + 6, x, y) - disc(M3_INSERT / 2, BASE_Z1, BASE_Z1 + 7, x, y)
    # bosses the top shell's posts sit on; M3x25 screws come up from underneath into the shell's inserts
    for x, y in SHELL_BOSSES:
        body += disc(4.5, BASE_Z1, 0, x, y)
        body -= disc(M3_CLEAR / 2, BASE_Z0 - 1, 1, x, y) + disc(3.2, BASE_Z0 - 1, BASE_Z0 + 2, x, y)
    body -= _servo_case_bottom_holes()
    body -= _servo_pockets(FIT) & box(-200, 200, -200, 200, BASE_Z1, 60)   # servo pockets
    return max(body.solids(), key=lambda s: s.volume)      # drop slivers left by the keep-out cuts


def top_shell():
    """Cosmetic carapace with eye stalks and a camera tunnel, sitting on the chassis (z = 0).

    Built from a top-view outline ("planform") that leaves out the bracket sweep zones and
    the low-lying servos, smoothed so no feature is thinner than 2 mm. The dome is clipped to
    that outline and hollowed 2 mm inside it, so every edge is a 2 mm rim, never a sliver."""
    a, b, c, t = 70.0, 100.0, 40.0, 2.0                    # tall enough to clear the shoulder servos
    from shapely.geometry import Point
    from shapely.ops import unary_union
    horns = unary_union([Point(x, y).buffer(24, 64) for _, x, y, _ in yaw_mounts()])   # yaw horns + plates
    planform = opened(_ellipse2d(a, b).difference(keepouts2d("shell")).difference(horns)
                      .difference(_pockets2d(2.0)), 1.0)
    planform = planform.simplify(0.15, preserve_topology=True)       # fewer, longer edges: valid booleans
    inner_pf = opened(planform.buffer(-t, 16), 0.5).simplify(0.15, preserve_topology=True)
    dome_o = b3d_scale(Sphere(1), by=(a, b, c)) & box(-200, 200, -200, 200, 0, 100)
    dome_i = b3d_scale(Sphere(1), by=(a - t, b - t, c - t))
    # prisms start below z=0 so no prism face coincides with the dome's cut plane
    outer = dome_o & (Pos(0, 0, -5) * extrude(to_face(planform), 110))
    hollow = dome_i & (Pos(0, 0, -5) * extrude(to_face(inner_pf), 110))
    shell = (outer - hollow).fix()
    # eye stalks (crab!): placed on solid shell - the most forward spots >= 6 mm inside the outline
    from shapely.geometry import Point as SPoint
    safe = planform.buffer(-6.0, 16)
    ex, ey = None, None
    for x in [v * 0.5 for v in range(int(a * 2), 0, -1)]:
        if safe.contains(SPoint(x, 20.0)) and safe.contains(SPoint(x, -20.0)):
            ex, ey = x, 20.0
            break
    if ex is not None:
        for s in (1, -1):
            z_top = c * (1 - (ex / a) ** 2 - (ey / b) ** 2) ** 0.5           # dome surface there
            stalk = Pos(ex, s * ey, z_top - 4 + 7) * Cylinder(4.0, 14) + Pos(ex, s * ey, z_top + 13) * Sphere(7.5)
            shell = shell.fuse(stalk)
    # add-ons are clipped 0.5 mm *inside* the outer surface: they overlap the wall instead of sharing
    # its surface (coincident curved faces break OCC booleans)
    dome_mid = b3d_scale(Sphere(1), by=(a - 0.5, b - 0.5, c - 0.5)) & box(-200, 200, -200, 200, -1, 100)
    # camera tunnel: window through the front, 2 mm tube behind it (the camera board sits at its end)
    tube = (cyl_x(8.5 + t, 55, 85, 0, CAMERA_Z) - cyl_x(8.5, 50, 90, 0, CAMERA_Z)) & dome_mid
    shell = (shell - cyl_x(8.5, 40, 90, 0, CAMERA_Z)).fuse(tube)
    # two screw posts down to the chassis bosses (M3 heat-set insert from below)
    for x, y in SHELL_BOSSES:
        post = (disc(4.5, 0, 45, x, y) & dome_mid) - disc(M3_INSERT / 2, -1, 7, x, y)
        shell = shell.fuse(post)
    return max(shell.solids(), key=lambda s: s.volume)
