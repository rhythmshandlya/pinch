"""Runtime for the real crab (Raspberry Pi) and its simulated stand-in."""
