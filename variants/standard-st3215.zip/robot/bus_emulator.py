"""Byte-level emulation of a chain of Feetech bus servos, for testing without hardware.

EmulatedPort behaves like a serial port: the driver writes real packets, every addressed
servo parses them against its own register memory and answers with real status packets.
An optional `physics` object links the servos to the MuJoCo simulator:
    physics.set_goal(servo_id, rad)  /  physics.get_state(servo_id) -> dict(position, speed, ...)
"""

from robot.feetech_bus import (BROADCAST, PING, READ, SYNC_READ, SYNC_WRITE, WRITE, Model, checksum)


class EmulatedServo:
    def __init__(self, sid: int, model: Model):
        self.m = model
        self.mem = bytearray(256)
        self.mem[5] = sid
        self._put("model", 9 if model.name == "scs0009" else 0x0309)
        self._put("present_position", model.centre)
        self._put("goal_position", model.centre)
        self._put("present_voltage", 60 if model.name == "scs0009" else 74)
        self._put("present_temperature", 32)
        self.mem[self.m.reg["lock"][0]] = 1

    @property
    def id(self):
        return self.mem[5]

    def _put(self, name, value):
        a, s = self.m.reg[name]
        self.mem[a:a + s] = (value & ((1 << 8 * s) - 1)).to_bytes(s, "little" if self.m.little_endian else "big")

    def _get(self, name):
        a, s = self.m.reg[name]
        return int.from_bytes(self.mem[a:a + s], "little" if self.m.little_endian else "big")

    def write_mem(self, addr, data):
        eeprom = addr < 40                               # EEPROM area is write-protected while locked
        if eeprom and self.mem[self.m.reg["lock"][0]] == 1:
            return 0x08                                   # "instruction error" flag
        self.mem[addr:addr + len(data)] = data
        return 0


class EmulatedPort:
    def __init__(self, model: Model, ids, physics=None, extra=None):
        self.m = model
        self.servos = {i: EmulatedServo(i, model) for i in ids}
        for s in (extra or []):                           # e.g. a brand-new servo still at ID 1
            self.servos[s.id] = s
        self.physics = physics
        self.rx = bytearray()
        self.log = []                                     # (instr, ids) for tests

    # serial-port interface
    def write(self, data: bytes):
        buf = bytes(data)
        while len(buf) >= 6 and buf[:2] == b"\xff\xff":
            sid, length, instr = buf[2], buf[3], buf[4]
            params, chk = buf[5:3 + length], buf[3 + length]      # LEN counts params + instr + chk
            if checksum(bytes([sid, length, instr]) + params) == chk:
                self._handle(sid, instr, params)
            buf = buf[4 + length:]
        return len(data)

    def read(self, n: int) -> bytes:
        out, self.rx[:] = bytes(self.rx[:n]), self.rx[n:]
        return out

    def reset_input_buffer(self):
        self.rx.clear()

    # protocol
    def _reply(self, servo, err=0, params=b""):
        body = bytes([servo.id, len(params) + 2, err]) + params
        self.rx += b"\xff\xff" + body + bytes([checksum(body)])

    def _refresh(self, servo):
        if self.physics is not None:
            st = self.physics.get_state(servo.id)
            servo._put("present_position", self.m.rad_to_raw(st["position"]))
            spd = int(round(st["speed"] * self.m.steps / self.m.span))
            servo._put("present_speed", (abs(spd) | (0x8000 if spd < 0 else 0)) & 0xFFFF)
            ld = int(round(st["load"] * 1000))
            servo._put("present_load", (min(abs(ld), 1000) | (0x400 if ld < 0 else 0)))
            servo._put("present_voltage", int(round(st["voltage"] * 10)))
            servo._put("present_temperature", int(st["temperature"]))

    def _after_write(self, servo, addr):
        if self.physics is None:
            return
        ga = self.m.reg["goal_position"][0]
        if addr <= ga < addr + 2 or addr == ga:
            self.physics.set_goal(servo.id, self.m.raw_to_rad(servo._get("goal_position")))
        ta = self.m.reg["torque_enable"][0]
        if addr == ta:
            self.physics.set_torque(servo.id, bool(servo.mem[ta]))

    def _handle(self, sid, instr, p):
        if instr == SYNC_WRITE and sid == BROADCAST:
            addr, size = p[0], p[1]
            ids = []
            for k in range(2, len(p), size + 1):
                s = self.servos.get(p[k])
                if s:
                    s.write_mem(addr, p[k + 1:k + 1 + size])
                    self._after_write(s, addr)
                    ids.append(p[k])
            self.log.append(("sync_write", tuple(ids)))
            return
        if instr == SYNC_READ and sid == BROADCAST and self.m.sync_read:
            addr, size = p[0], p[1]
            for i in p[2:]:
                s = self.servos.get(i)
                if s:
                    self._refresh(s)
                    self._reply(s, 0, bytes(s.mem[addr:addr + size]))
            self.log.append(("sync_read", tuple(p[2:])))
            return
        s = self.servos.get(sid)
        if s is None:
            return                                         # nobody answers: timeout
        if instr == PING:
            self._reply(s)
        elif instr == READ:
            self._refresh(s)
            self._reply(s, 0, bytes(s.mem[p[0]:p[0] + p[1]]))
        elif instr == WRITE:
            old_id = s.id
            err = s.write_mem(p[0], p[1:])
            if s.id != old_id:                             # ID change: re-register under the new ID
                self.servos[s.id] = self.servos.pop(old_id)
            self._reply(s, err)
            self._after_write(s, p[0])
        self.log.append((instr, (sid,)))
