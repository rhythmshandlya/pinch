"""Self-test of the robot software against the simulated robot (no hardware needed).

    python robot/selftest.py

Checks the exact code path the Raspberry Pi will run, with SimBackend standing in
for the servo bus, IMU and battery:
  1. joint <-> raw servo position conversion round-trips
  2. calibration recovers random horn offsets (25T spline + assembly slop)
  3. with that calibration, the robot reaches the commanded pose (< 1 deg error)
  4. the safety layer clamps joint limits and limits servo speed
  5. low battery triggers a safety stop (torque off)
  6. the robot stack walks: trot forward, crab-walk sideways
"""

import sys
from math import pi
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from crab.emotes import STAND  # noqa: E402
from crab.params import JOINT_NAMES  # noqa: E402
from robot.backends import SimBackend, random_horn_offsets  # noqa: E402
from robot.calibrate import CAL_POSE, measure_offsets  # noqa: E402
from robot.crab_robot import MAX_STEP, Crab, SafetyStop  # noqa: E402
from robot.servos import Calibration, raw_to_rad, rad_to_raw  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))


def calibrated_backend(seed=3):
    truth = random_horn_offsets(seed)
    hw = SimBackend(mount_offsets=truth)
    hw.torque(False)
    hw.held = CAL_POSE                     # the person holds the robot in the calibration pose
    hw.wait(0.01)
    cal = measure_offsets(hw)
    # fresh backend with the same physical offsets, standing
    return SimBackend(mount_offsets=truth), cal, truth


def main():
    print("robot software self-test (simulated hardware)")

    errs = [abs(raw_to_rad(rad_to_raw(a)) - a) for a in np.linspace(-pi + 0.01, pi - 0.01, 101)]
    check("raw <-> radian conversion", max(errs) < 2 * pi / 4096, f"max err {np.degrees(max(errs)):.3f} deg")

    hw, cal, truth = calibrated_backend()
    err = max(abs(cal.offset[j] - truth[j]) for j in JOINT_NAMES)
    check("calibration recovers horn offsets", err < np.radians(0.5), f"worst {np.degrees(err):.3f} deg")

    crab = Crab(hw, calibration=cal)
    crab.start()
    crab.move_to(STAND, 1.0)
    for _ in range(25):
        crab.tick(STAND)
    q, _ = crab.read_joints()
    true_q = np.array([hw.d.qpos[hw.qadr[j]] for j in JOINT_NAMES])
    e_meas = np.degrees(np.abs(q - true_q).max())
    e_pose = np.degrees(np.abs(true_q - STAND).max())
    check("calibrated robot reaches the stand pose", e_pose < 3.0,
          f"max joint error {e_pose:.2f} deg (gravity sag incl.), sensing error {e_meas:.3f} deg")

    uncal = Crab(SimBackend(mount_offsets=truth), calibration=Calibration())
    uncal.start()
    for _ in range(25):
        uncal.tick(STAND)
    tq = np.array([uncal.hw.d.qpos[uncal.hw.qadr[j]] for j in JOINT_NAMES])
    check("...and without calibration it would be off (sanity)", np.degrees(np.abs(tq - STAND).max()) > 3.0,
          f"{np.degrees(np.abs(tq - STAND).max()):.1f} deg off")

    before = crab.q_cmd.copy()
    wild = STAND.copy()
    wild[JOINT_NAMES.index("FL_femur")] = -3.0                    # far outside the CAD limit
    after = crab.tick(wild)
    i = JOINT_NAMES.index("FL_femur")
    check("speed limit per 20 ms tick", abs(after[i] - before[i]) <= MAX_STEP + 1e-9,
          f"moved {np.degrees(abs(after[i] - before[i])):.1f} deg in one tick")
    for _ in range(100):
        crab.tick(wild)
    check("joint limit clamp", crab.q_cmd[i] >= crab.lo[i] - 1e-9, f"held at {np.degrees(crab.q_cmd[i]):.0f} deg")
    crab.move_to(STAND, 1.0)

    x0 = hw.d.qpos[0]
    crab.walk((0.08, 0.0, 0.0), seconds=4.0)
    dx = hw.d.qpos[0] - x0
    check("robot stack walks forward (trot)", dx > 0.15, f"moved {dx * 100:.1f} cm in 4 s")
    y0 = hw.d.qpos[1]
    crab.walk((0.0, 0.10, 0.0), seconds=4.0)
    dy = hw.d.qpos[1] - y0
    check("robot stack crab-walks sideways", dy > 0.2, f"moved {dy * 100:.1f} cm left in 4 s")
    crab.play_emote("wave")
    check("emote plays through the robot stack", True)

    hw.voltage = 6.2                                                # battery sagging below the cut-off
    stopped = False
    try:
        for _ in range(200):
            crab.tick(STAND)
    except SafetyStop as e:
        stopped = "battery" in str(e)
    check("low-battery safety stop (torque off)", stopped and not hw.torque_on)

    # ---- our own Feetech driver against the byte-level emulated bus --------------------
    from robot.bus_emulator import EmulatedPort
    from robot.backends import emulated_bus_backend
    from robot.feetech_bus import MODELS, FeetechBus, checksum, packet
    from robot.setup_servo import setup
    pk = packet(1, 0x01)
    check("packet + checksum (PING)", pk == bytes([0xFF, 0xFF, 1, 2, 1, checksum(bytes([1, 2, 1]))]))
    for mname in ("sts3215", "scs0009"):
        m = MODELS[mname]
        port = EmulatedPort(m, [3, 4, 5])
        bus = FeetechBus(port, m)
        ok = bus.ping(3) and not bus.ping(9)
        bus.sync_write("goal_position", {3: 100, 4: 900, 5: 511})
        ok &= [port.servos[i]._get("goal_position") for i in (3, 4, 5)] == [100, 900, 511]
        port.servos[4]._put("present_position", 777)
        ok &= bus.sync_read("present_position", [3, 4, 5])[4] == 777
        # EEPROM is locked: a raw ID write is refused; set_id unlocks, writes, relocks
        try:
            bus.write(5, "id", 9)
            refused = False
        except Exception:
            refused = True
        bus.set_id(5, 9)
        ok &= refused and bus.ping(9) and not bus.ping(5)
        check(f"{mname}: ping, sync write/read, EEPROM lock, ID change ({'little' if m.little_endian else 'big'}-endian)", ok)
        new = EmulatedPort(m, [1])
        setup(FeetechBus(new, m), 12, log=lambda *_: None)
        s = new.servos[12]
        check(f"{mname}: setup_servo flow on a brand-new servo", s._get("p_gain") == 32 and s.mem[m.reg['lock'][0]] == 1
              and s._get("goal_position") == m.centre)

    truth2 = random_horn_offsets(5)
    bb = emulated_bus_backend(mount_offsets=truth2)
    bb.sim.torque(False)
    bb.sim.held = CAL_POSE
    bb.wait(0.01)                                                    # let the "hands" take hold first
    cal2 = measure_offsets(bb)
    err2 = max(abs(cal2.offset[j] - truth2[j]) for j in JOINT_NAMES)
    check("calibration through the bus (raw counts)", err2 < np.radians(0.2), f"worst {np.degrees(err2):.2f} deg")
    bb = emulated_bus_backend(mount_offsets=truth2)                  # fresh robot, same horns
    crab2 = Crab(bb, calibration=cal2)
    crab2.start()
    x0 = bb.sim.d.qpos[0]
    crab2.walk((0.08, 0.0, 0.0), seconds=3.0)
    dx = bb.sim.d.qpos[0] - x0
    check("walks with every command going through the byte-level bus", dx > 0.1, f"{dx * 100:.1f} cm in 3 s")

    print(f"\n{sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
