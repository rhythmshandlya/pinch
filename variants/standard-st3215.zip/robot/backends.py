"""Hardware backends with one interface, so the robot code runs unchanged on
the real crab or in the simulator.

    write_positions({id: servo_rad})      # goal positions
    read_state() -> {id: ServoState}      # position (rad), speed (rad/s), load (-1..1), volts, temp C
    read_imu() -> (gyro[3] rad/s, gravity[3] unit vector, body frame)
    wait(dt)                              # real: sleep to keep the loop period; sim: advance physics
    torque(enable: bool)

RealBackend talks to the servos through rustypot (Pollen Robotics) over the
Feetech FE-URT-1 USB adapter, and to the BNO055 IMU over I2C.
SimBackend runs the MuJoCo model; its servos can be "mounted" with random horn
offsets so calibration can be tested before the hardware exists.
"""

import time
from dataclasses import dataclass
from math import pi

import numpy as np

from crab.params import JOINT_NAMES
from robot.servos import SERVO_IDS, default_sign


@dataclass
class ServoState:
    position: float      # rad, servo frame
    speed: float         # rad/s
    load: float          # -1..1 of max torque
    voltage: float       # V
    temperature: float   # C


class SimBackend:
    """MuJoCo stands in for the robot. `mount_offsets` = physical horn offsets (rad) per joint."""

    def __init__(self, mount_offsets=None, render=False, voltage=7.4):
        import mujoco
        from pathlib import Path
        self.mj = mujoco
        root = Path(__file__).resolve().parents[1]
        self.m = mujoco.MjModel.from_xml_path(str(root / "sim" / "models" / "crab.xml"))
        self.d = mujoco.MjData(self.m)
        mujoco.mj_resetDataKeyframe(self.m, self.d, self.m.key("stand").id)
        self.mount = {j: 0.0 for j in JOINT_NAMES} if mount_offsets is None else dict(mount_offsets)
        self.sign = {j: default_sign(j) for j in JOINT_NAMES}
        self.qadr = {j: self.m.jnt_qposadr[self.m.joint(j).id] for j in JOINT_NAMES}
        self.vadr = {j: self.m.jnt_dofadr[self.m.joint(j).id] for j in JOINT_NAMES}
        # gear-play joints (if the model has them): the encoder sits on the output shaft, after the play
        names = {self.m.joint(i).name for i in range(self.m.njnt)}
        self.bl_qadr = {j: self.m.jnt_qposadr[self.m.joint(f"{j}_backlash").id]
                        for j in JOINT_NAMES if f"{j}_backlash" in names}
        self.bl_vadr = {j: self.m.jnt_dofadr[self.m.joint(f"{j}_backlash").id] for j in self.bl_qadr}
        self.act = {j: self.m.actuator(j).id for j in JOINT_NAMES}
        self.by_id = {i: j for j, i in SERVO_IDS.items()}
        self.torque_on = True
        self.voltage = voltage
        self.held = None          # joint vector: "a person holds the robot in this pose" (calibration rehearsal)
        self.viewer = None
        if render:
            import mujoco.viewer
            self.viewer = mujoco.viewer.launch_passive(self.m, self.d)

    def link_angle(self, j):          # true joint angle of the link (servo + gear play)
        q = self.d.qpos[self.qadr[j]]
        return q + (self.d.qpos[self.bl_qadr[j]] if j in self.bl_qadr else 0.0)

    def link_speed(self, j):
        w = self.d.qvel[self.vadr[j]]
        return w + (self.d.qvel[self.bl_vadr[j]] if j in self.bl_vadr else 0.0)

    def _servo_angle(self, j):        # what the physical servo would report
        return self.sign[j] * self.link_angle(j) + self.mount[j]

    def write_positions(self, goals):
        for sid, s_rad in goals.items():
            j = self.by_id[sid]
            self.d.ctrl[self.act[j]] = (s_rad - self.mount[j]) * self.sign[j]

    def read_state(self):
        out = {}
        for sid, j in self.by_id.items():
            f = self.d.actuator_force[self.act[j]]
            out[sid] = ServoState(position=float(self._servo_angle(j)),
                                  speed=float(self.sign[j] * self.link_speed(j)),
                                  load=float(np.clip(self.sign[j] * f / 3.52, -1, 1)),
                                  voltage=self.voltage, temperature=35.0)
        return out

    def read_imu(self):
        R = self.d.xmat[1].reshape(3, 3)
        return self.d.qvel[3:6].copy(), R.T @ np.array([0, 0, -1.0])

    def torque(self, enable):
        self.torque_on = enable
        if not enable:      # limp: let joints follow gravity (zero actuator stiffness)
            self.m.actuator_gainprm[:, 0] = 0
            self.m.actuator_biasprm[:, 1] = 0

    def wait(self, dt):
        if self.held is not None:                       # held by hand: joints don't move
            for i, j in enumerate(JOINT_NAMES):
                self.d.qpos[self.qadr[j]] = self.held[i]
                if j in self.bl_qadr:
                    self.d.qpos[self.bl_qadr[j]] = 0.0
            self.d.qvel[:] = 0
            self.mj.mj_forward(self.m, self.d)
            return
        for _ in range(max(1, int(round(dt / self.m.opt.timestep)))):
            self.mj.mj_step(self.m, self.d)
        if self.viewer is not None:
            self.viewer.sync()
            time.sleep(dt)

    def close(self):
        if self.viewer is not None:
            self.viewer.close()


class BusBackend:
    """Servos through our own Feetech driver (robot/feetech_bus.py) over any serial-like port:
    pyserial + FE-URT-2 on the Raspberry Pi, or robot.bus_emulator.EmulatedPort in tests.

    imu:   object with read() -> (gyro, gravity_unit), or None
    clock: wait(dt) function; default sleeps in real time (tests pass the simulator's)
    """

    def __init__(self, port, model, imu=None, clock=None):
        from robot.feetech_bus import FeetechBus
        self.bus = FeetechBus(port, model)
        self.ids = list(SERVO_IDS.values())
        self.imu = imu
        self._clock = clock
        self._t = time.monotonic()

    def write_positions(self, goals):
        self.bus.goal_positions(goals)

    def read_state(self):
        return {i: ServoState(**self.bus.state(i)) for i in self.ids}

    def read_imu(self):
        if self.imu is None:
            return np.zeros(3), np.array([0.0, 0.0, -1.0])
        return self.imu.read()

    def torque(self, enable):
        self.bus.torque(self.ids, enable)

    def wait(self, dt):
        if self._clock is not None:
            return self._clock(dt)
        self._t += dt
        delay = self._t - time.monotonic()
        if delay > 0:
            time.sleep(delay)
        else:
            self._t = time.monotonic()                     # fell behind: resync

    def close(self):
        try:
            self.torque(False)
        except Exception:
            pass


class BNO055:
    """IMU on the Pi's I2C (pip install adafruit-circuitpython-bno055). Mount flat, x arrow forward."""

    def __init__(self):
        import board
        import adafruit_bno055
        self.dev = adafruit_bno055.BNO055_I2C(board.I2C())

    def read(self):
        g = np.asarray(self.dev.gyro or (0.0, 0.0, 0.0), float)              # rad/s
        v = np.asarray(self.dev.gravity or (0.0, 0.0, -9.81), float)         # m/s^2 toward the ground
        n = np.linalg.norm(v)
        return g, (v / n if n > 0 else np.array([0.0, 0.0, -1.0]))


def RealBackend(port="/dev/ttyUSB0", baudrate=1_000_000, imu=True):
    """The physical crab: servos via FE-URT-2 (pip install pyserial), IMU via I2C."""
    import serial
    from robot.feetech_bus import MODELS
    from crab.params import PARAMS
    ser = serial.Serial(port, baudrate=baudrate, timeout=0.02)
    return BusBackend(ser, MODELS[PARAMS.servo.bus_model], imu=BNO055() if imu else None)


class SimPhysics:
    """Lets the emulated servo bus drive the MuJoCo simulator (used by tests)."""

    def __init__(self, sim: "SimBackend"):
        self.sim = sim

    def set_goal(self, sid, rad):
        self.sim.write_positions({sid: rad})

    def set_torque(self, sid, on):
        pass                                               # whole-robot torque handled by the test

    def get_state(self, sid):
        s = self.sim.read_state()[sid]
        return dict(position=s.position, speed=s.speed, load=s.load, voltage=s.voltage, temperature=s.temperature)


def emulated_bus_backend(mount_offsets=None):
    """Full software stack down to the bytes: driver -> emulated servos -> MuJoCo physics."""
    from robot.bus_emulator import EmulatedPort
    from robot.feetech_bus import MODELS
    from crab.params import PARAMS
    model = MODELS[PARAMS.servo.bus_model]
    sim = SimBackend(mount_offsets=mount_offsets)
    port = EmulatedPort(model, list(SERVO_IDS.values()), physics=SimPhysics(sim))
    imu = type("SimIMU", (), {"read": lambda self: sim.read_imu()})()
    be = BusBackend(port, model, imu=imu, clock=sim.wait)
    be.sim = sim
    return be


def random_horn_offsets(seed=0):
    """Physical mounting error: the 25T spline puts a horn within +-7.2 deg of intent, plus assembly slop."""
    rng = np.random.default_rng(seed)
    return {j: float(rng.uniform(-7.2, 7.2) * pi / 180 + rng.normal(0, 1.0) * pi / 180) for j in JOINT_NAMES}
