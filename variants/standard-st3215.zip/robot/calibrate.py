"""Measure each servo's horn offset (run once after assembly, and after replacing a servo).

    python robot/calibrate.py            # real robot (Raspberry Pi)
    python robot/calibrate.py --sim      # rehearse in the simulator with random horn offsets

Procedure (real robot): torque is switched OFF; you hold the crab in the
calibration pose and press Enter. The pose is "everything straight":
  * legs pointing straight out from their hip (along the arrow on the chassis),
    thigh and shin in one straight horizontal line
  * arms straight forward-out along their shoulder arrow, horizontal, claws closed
A straight edge along each limb is enough (a 1 deg error ~ 2 mm at the foot).
Writes robot/calibration.json.
"""

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from crab.params import JOINT_NAMES  # noqa: E402
from robot.servos import SERVO_IDS, Calibration  # noqa: E402

CAL_POSE = np.zeros(len(JOINT_NAMES))     # "everything straight" = all joint angles 0


def measure_offsets(backend, cal_pose=CAL_POSE, samples=10):
    """With the robot held in cal_pose, offset = servo_angle - sign * joint_angle (averaged)."""
    cal = Calibration()                    # default signs, zero offsets
    acc = np.zeros(len(JOINT_NAMES))
    for _ in range(samples):
        st = backend.read_state()
        acc += [st[SERVO_IDS[j]].position for j in JOINT_NAMES]
        backend.wait(0.01)
    servo = acc / samples
    for i, j in enumerate(JOINT_NAMES):
        cal.offset[j] = float(servo[i] - cal.sign[j] * cal_pose[i])
    return cal


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sim", action="store_true", help="rehearse in simulation with random horn offsets")
    a = ap.parse_args()
    if a.sim:
        from robot.backends import SimBackend, random_horn_offsets
        truth = random_horn_offsets(seed=7)
        hw = SimBackend(mount_offsets=truth)
        hw.torque(False)
        hw.held = CAL_POSE                 # the "user" holds the robot in the pose
        hw.wait(0.01)
        cal = measure_offsets(hw)
        err = max(abs(cal.offset[j] - truth[j]) for j in JOINT_NAMES)
        print(f"recovered horn offsets, worst error {np.degrees(err):.3f} deg")
        return 0 if err < np.radians(0.5) else 1
    from robot.backends import RealBackend
    hw = RealBackend()
    hw.torque(False)
    input("Torque is OFF. Hold the crab in the calibration pose (see docstring), then press Enter... ")
    cal = measure_offsets(hw)
    for j in JOINT_NAMES:
        print(f"  {j:18s} offset {np.degrees(cal.offset[j]):7.2f} deg")
        if abs(cal.offset[j]) > np.radians(20):
            print("    ! more than 20 deg: was that horn mounted a few spline teeth off? (see assembly guide)")
    cal.save()
    print("saved robot/calibration.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
