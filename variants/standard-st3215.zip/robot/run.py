"""Run the crab: real robot (on the Raspberry Pi) or the simulated stand-in.

    python robot/run.py --sim                    # demo in the MuJoCo viewer
    python robot/run.py --sim --emote happy
    python robot/run.py                          # real robot (after setup_servo + calibrate)
    python robot/run.py --policy training/checkpoints/colab-full    # learned walking
"""

import argparse
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from robot.crab_robot import Crab, SafetyStop  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sim", action="store_true", help="use the simulator instead of the real servos")
    ap.add_argument("--emote", help="play one emote and exit")
    ap.add_argument("--policy", help="trained RL run dir for walking (default: scripted gait)")
    ap.add_argument("--port", default="/dev/ttyUSB0")
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    if a.sim:
        from robot.backends import SimBackend
        hw = SimBackend(render=True)
    else:
        from robot.backends import RealBackend
        hw = RealBackend(port=a.port)

    crab = Crab(hw)
    try:
        crab.start()
        if a.emote:
            crab.play_emote(a.emote)
        elif a.policy:
            crab.run_policy(a.policy, lambda t: (0.06, 0.0, 0.0) if t < 5 else (0.0, 0.08, 0.0), seconds=10)
        else:
            for name in ("wave", "happy"):
                crab.play_emote(name)
            crab.walk((0.08, 0, 0), 3)
            crab.walk((0, 0.10, 0), 3)
            crab.walk((0, -0.10, 0), 3)
            crab.walk((0, 0, 0.6), 3)
            crab.play_emote("angry")
        crab.shutdown()
    except SafetyStop as e:
        logging.error("stopped for safety: %s", e)
    except KeyboardInterrupt:
        crab.shutdown()


if __name__ == "__main__":
    main()
