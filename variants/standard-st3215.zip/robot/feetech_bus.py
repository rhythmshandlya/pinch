"""Minimal Feetech serial-bus servo driver (SCS / STS protocol), pure Python.

Works over anything with write(bytes) / read(n): a pyserial port on the Raspberry Pi
(through the Feetech FE-URT-2 USB adapter), or robot.bus_emulator.EmulatedPort in tests.

Packet:  FF FF ID LEN INSTR PARAM... CHK      LEN = n_params + 2
         CHK = ~(ID + LEN + INSTR + sum(PARAM)) & 0xFF
Status:  FF FF ID LEN ERR  PARAM... CHK

Register maps follow Feetech's own SDK (FTServo_Python: sms_sts.py for STS, scscl.py for SCS).
Two differences matter: STS stores 2-byte values little-endian, SCS big-endian; STS has
4096 steps / 360 deg (centre 2048), the SCS0009 1024 steps / 300 deg (centre 511).
"""

import time
from dataclasses import dataclass
from math import pi, radians

PING, READ, WRITE, REG_WRITE, ACTION, RESET, SYNC_READ, SYNC_WRITE = 0x01, 0x02, 0x03, 0x04, 0x05, 0x0A, 0x82, 0x83
BROADCAST = 0xFE


@dataclass(frozen=True)
class Model:
    name: str
    little_endian: bool
    steps: int            # position counts over `span`
    span: float           # rad covered by `steps`
    centre: int           # raw position for 0 rad
    reg: dict             # register name -> (address, size)
    sync_read: bool       # supports SYNC_READ (0x82)

    def rad_to_raw(self, rad: float) -> int:
        return int(round(self.centre + rad * self.steps / self.span))

    def raw_to_rad(self, raw: int) -> float:
        return (raw - self.centre) * self.span / self.steps


_COMMON = {
    "model": (3, 2), "id": (5, 1), "baud": (6, 1), "return_delay": (7, 1),
    "min_angle": (9, 2), "max_angle": (11, 2), "max_temp": (13, 1),
    "max_voltage": (14, 1), "min_voltage": (15, 1), "max_torque": (16, 2),
    "torque_enable": (40, 1), "goal_position": (42, 2), "goal_time": (44, 2), "goal_speed": (46, 2),
    "present_position": (56, 2), "present_speed": (58, 2), "present_load": (60, 2),
    "present_voltage": (62, 1), "present_temperature": (63, 1), "moving": (66, 1), "present_current": (69, 2),
}
STS3215 = Model("sts3215", True, 4096, 2 * pi, 2048,
                {**_COMMON, "p_gain": (21, 1), "d_gain": (22, 1), "i_gain": (23, 1),
                 "acceleration": (41, 1), "torque_limit": (48, 2), "lock": (55, 1)}, True)
SCS0009 = Model("scs0009", False, 1024, radians(300), 511,
                {**_COMMON, "p_gain": (21, 1), "d_gain": (22, 1), "i_gain": (23, 1), "lock": (48, 1)}, False)
MODELS = {m.name: m for m in (STS3215, SCS0009)}


class BusError(IOError):
    pass


def checksum(body: bytes) -> int:
    return (~sum(body)) & 0xFF


def packet(sid: int, instr: int, params: bytes = b"") -> bytes:
    body = bytes([sid, len(params) + 2, instr]) + bytes(params)
    return b"\xff\xff" + body + bytes([checksum(body)])


class FeetechBus:
    def __init__(self, port, model: Model, retries: int = 2):
        self.port, self.m, self.retries = port, model, retries

    # -- encoding ----------------------------------------------------------
    def _enc(self, value: int, size: int) -> bytes:
        value &= (1 << (8 * size)) - 1
        return value.to_bytes(size, "little" if self.m.little_endian else "big")

    def _dec(self, data: bytes) -> int:
        return int.from_bytes(data, "little" if self.m.little_endian else "big")

    @staticmethod
    def _signed(raw: int, sign_bit: int) -> int:
        """Feetech sign-magnitude: bit `sign_bit` set = negative."""
        mag = raw & ((1 << sign_bit) - 1)
        return -mag if raw & (1 << sign_bit) else mag

    # -- transport ---------------------------------------------------------
    def _status(self, expect_id: int) -> bytes:
        head = self.port.read(4)
        if len(head) < 4 or head[:2] != b"\xff\xff":
            raise BusError(f"no reply from servo {expect_id}")
        sid, length = head[2], head[3]
        rest = self.port.read(length)
        if len(rest) < length:
            raise BusError(f"short reply from servo {sid}")
        err, params, chk = rest[0], rest[1:-1], rest[-1]
        if checksum(bytes([sid, length, err]) + params) != chk:
            raise BusError(f"bad checksum from servo {sid}")
        if sid != expect_id:
            raise BusError(f"reply from {sid}, expected {expect_id}")
        if err:
            raise BusError(f"servo {sid} error flags 0x{err:02x}")
        return params

    def _txrx(self, sid, instr, params=b"", reply=True):
        last = None
        for _ in range(self.retries + 1):
            self.port.write(packet(sid, instr, params))
            if not reply or sid == BROADCAST:
                return b""
            try:
                return self._status(sid)
            except BusError as e:
                last = e
        raise last

    # -- primitives --------------------------------------------------------
    def ping(self, sid) -> bool:
        try:
            self._txrx(sid, PING)
            return True
        except BusError:
            return False

    def read(self, sid, name) -> int:
        addr, size = self.m.reg[name]
        return self._dec(self._txrx(sid, READ, bytes([addr, size])))

    def write(self, sid, name, value: int):
        addr, size = self.m.reg[name]
        self._txrx(sid, WRITE, bytes([addr]) + self._enc(value, size))

    def sync_write(self, name, values: dict):
        """One packet sets the same register on many servos (no replies)."""
        addr, size = self.m.reg[name]
        params = bytes([addr, size]) + b"".join(bytes([sid]) + self._enc(v, size) for sid, v in values.items())
        self._txrx(BROADCAST, SYNC_WRITE, params, reply=False)

    def sync_read(self, name, ids) -> dict:
        addr, size = self.m.reg[name]
        if not self.m.sync_read:                       # SCS: read one by one
            return {sid: self.read(sid, name) for sid in ids}
        self.port.write(packet(BROADCAST, SYNC_READ, bytes([addr, size]) + bytes(ids)))
        return {sid: self._dec(self._status(sid)) for sid in ids}

    def read_block(self, sid, first, last) -> dict:
        """Read consecutive registers first..last in one transaction."""
        a0, _ = self.m.reg[first]
        a1, s1 = self.m.reg[last]
        data = self._txrx(sid, READ, bytes([a0, a1 + s1 - a0]))
        out = {}
        for name, (a, s) in self.m.reg.items():
            if a0 <= a and a + s <= a1 + s1:
                out[name] = self._dec(data[a - a0:a - a0 + s])
        return out

    # -- robot-level helpers --------------------------------------------------
    def set_id(self, old, new):
        """The reply to an ID write may come back under either ID, so don't wait for it:
        send, drop whatever answers, then confirm by pinging the new ID."""
        self.write(old, "lock", 0)
        addr, size = self.m.reg["id"]
        self._txrx(old, WRITE, bytes([addr]) + self._enc(new, size), reply=False)
        time.sleep(0.005)
        if hasattr(self.port, "reset_input_buffer"):
            self.port.reset_input_buffer()
        if not self.ping(new):
            raise BusError(f"servo did not come back as ID {new}")
        self.write(new, "lock", 1)

    def torque(self, ids, enable=True):
        self.sync_write("torque_enable", {i: int(bool(enable)) for i in ids})

    def goal_positions(self, rad_by_id: dict):
        hi = self.m.steps - 1
        self.sync_write("goal_position", {i: min(hi, max(0, self.m.rad_to_raw(r))) for i, r in rad_by_id.items()})

    def state(self, sid) -> dict:
        r = self.read_block(sid, "present_position", "present_temperature")
        return {"position": self.m.raw_to_rad(r["present_position"]),
                "speed": self._signed(r["present_speed"], 15) * self.m.span / self.m.steps,
                "load": self._signed(r["present_load"], 10) / 1000.0,
                "voltage": r["present_voltage"] / 10.0,
                "temperature": float(r["present_temperature"])}
