"""Single source of truth for the order. Generates hardware/BOM.md and hardware/BOM.csv.

    python hardware/bom.py

Prices: robu.in incl. GST, checked 2026-11-18 (see robu_prices_raw.md). They change, so
re-check stock and prices in the cart before paying.
need: "required" | "recommended" | "optional"
"""

import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent

# (section, item, robu SKU, qty, unit price INR, need, note)
ITEMS = [
    # ------------------------------------------------------------- actuation
    ("Servos & bus", "Waveshare ST3215 serial bus servo 19.5 kg·cm @ 7.4 V (= Feetech STS3215)", "R258500", 22, 2159,
     "required", "20 + 2 spares. Must be the 7.4 V version (not the 12 V / 30 kg one)"),
    ("Servos & bus", "Feetech FE-URT-1 USB to bus-servo signal converter", "1110047", 1, 1069,
     "required", "Signal only; servo power goes through the power hub"),
    ("Servos & bus", "USB-A to Mini-B cable, ~30 cm (for FE-URT-1)", "search 'mini usb cable'", 1, 120,
     "required", "Price estimated"),
    # ------------------------------------------------------------- compute & sensing
    ("Compute & sensing", "Raspberry Pi 5 4GB", "1749032", 1, 13459, "required",
     "Runs the controller; the Gemma brain runs on your PC over Wi-Fi"),
    ("Compute & sensing", "Official Raspberry Pi 5 Active Cooler", "1749017", 1, 569, "required", ""),
    ("Compute & sensing", "SanDisk Ultra 64GB microSD", "630818", 1, 1999, "required", "Raspberry Pi OS"),
    ("Compute & sensing", "Raspberry Pi Camera Module 3 NoIR Wide", "1445417", 1, 4299, "required",
     "Camera Module 3 Wide (1445388) is better for colours; buy it instead if it's back in stock"),
    ("Compute & sensing", "Official Raspberry Pi 5 camera FPC cable 200 mm", "1749018", 1, 134, "required",
     "Pi 5 has the small 22-pin camera connector"),
    ("Compute & sensing", "7Semi BNO055 9-DOF IMU (Qwiic)", "R264684", 1, 1479, "required",
     "Gyro + gravity vector for the walking policy"),
    ("Compute & sensing", "Female-female jumper wires, 20 cm (pack)", "search 'jumper wire female'", 1, 80,
     "required", "IMU + Pi power; price estimated"),
    # ------------------------------------------------------------- power
    ("Power", "Bonka 7.4 V 3300 mAh 25C 2S LiPo (XT60, 135×44 mm, 190 g)", "1891446", 1, 2025, "required",
     "~24-46 min per charge (simulated)"),
    ("Power", "Second battery (same)", "1891446", 1, 2025, "optional", "Swap and keep playing"),
    ("Power", "SkyRC E3 AC 2-3S balance charger", "4511", 1, 1689, "required", "Plugs into the wall, beginner-proof"),
    ("Power", "200W 20A DC-DC buck converter (adjustable), set to 7.4 V", "815794", 1, 401, "required",
     "Servo power: caps a full LiPo's 8.4 V"),
    ("Power", "SmartElex TPS565201 buck 5 V 5 A", "R214562", 1, 249, "required", "Raspberry Pi power"),
    ("Power", "In-line blade fuse holders (5 pcs)", "699636", 1, 629, "required", "Need 1; spares are useful"),
    ("Power", "20A mini blade fuse", "R260449", 3, 19, "required", "1 + 2 spares"),
    ("Power", "ASW-15D 12 V 20 A toggle rocker switch", "R265191", 1, 159, "required", "Main power switch"),
    ("Power", "SafeConnect XT60 pair with lead, 14 AWG", "167101", 2, 197, "required", "Battery to switch, charger side"),
    ("Power", "Pro-Range 16 AWG silicone wire kit, 5 colours × 4 m", "R229101", 1, 1159, "required", "All power wiring"),
    ("Power", "LiPo voltage checker with buzzer 1-8S", "2753", 1, 210, "required", "Alarm at 3.5 V/cell"),
    ("Power", "LiPo explosion-proof bag 100×200 mm", "R260503", 1, 299, "required", "Charge and store the battery in it"),
    ("Power", "Pro-Range 30 cm battery strap", "R266940", 2, 56, "required", "Holds the battery under the body"),
    # ------------------------------------------------------------- assembly
    ("Assembly", "8×12 cm double-sided prototype PCB", "44139", 1, 114, "required", "Power hub"),
    ("Assembly", "2.54 mm 1×40 male header strip (long)", "539076", 2, 15, "required", "6 limb connectors on the hub"),
    ("Assembly", "Pro-Range heat-shrink kit, 12 sizes 850 pcs", "R189086", 1, 549, "required", ""),
    ("Assembly", "Brass heat-set inserts M2/M2.5/M3 kit, 500 pcs", "R267265", 1, 1349, "required",
     "Pressed into printed parts with the soldering iron"),
    ("Assembly", "EasyMech M3×6 bolt + nut set (25 pcs)", "55898", 4, 67, "required",
     "80 horn screws + shell + electronics deck"),
    ("Assembly", "EasyMech M2×6 socket head bolt + nut set (12 pcs)", "56219", 7, 239, "required",
     "Servo case screws, 2 per face (68 needed)"),
    ("Assembly", "EasyMech M3×25 countersunk screw", "R265631", 4, 59, "required",
     "Foot tips; price may be per piece or per pack"),
    # ------------------------------------------------------------- tools
    ("Tools", "YIHUA 926 temperature-controlled soldering station", "1316303", 1, 1509, "required", ""),
    ("Tools", "Solder wire 0.8 mm 50 g", "1837790", 1, 269, "required", ""),
    ("Tools", "Noel flux paste 10 g", "762465", 2, 21, "required", ""),
    ("Tools", "Pro-Range SM-830L auto-range multimeter", "R160668", 1, 599, "required", "Check voltages and polarity"),
    ("Tools", "Stanley wire stripper / cutter 130 mm", "1600571", 1, 369, "required", ""),
    ("Tools", "Taparia KM9V Allen key set 1.5-10 mm", "R111188", 1, 239, "required", "M2/M3 socket screws"),
    ("Tools", "32-in-1 precision screwdriver set", "1794161", 1, 229, "required", ""),
    ("Tools", "Wanptek WPS305H 30 V / 5 A bench power supply", "1628482", 1, 6961, "recommended",
     "Safe first power-up with a current limit"),
]

PRINT_SERVICE_NOTE = (
    "Upload the 10 STL files from cad/out/print/ to robu.in's 3D printing service "
    "(https://robu.in/product/3d-printing-service1/) and set quantities from cad/out/print_sheet.csv "
    "(26 pieces). Use PETG, and TPU for the 4 foot tips. About 490 g of printed parts plus supports; "
    "estimated cost ₹3,500-6,000. The real price is quoted instantly when you upload.")


def main():
    rows = []
    for sec, item, sku, qty, price, need, note in ITEMS:
        rows.append(dict(section=sec, item=item, sku=sku, qty=qty, unit_inr=price, total_inr=qty * price,
                         need=need, note=note))
    with open(HERE / "BOM.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    def total(pred):
        return sum(r["total_inr"] for r in rows if pred(r))

    lines = ["# Bill of materials: one robu.in order",
             "",
             "Generated by `python hardware/bom.py`. Prices are robu.in incl. GST as checked on **2026-11-18**.",
             "They change, so re-check stock in the cart before paying.",
             "Rows with an estimated price weren't found or checked on robu.in.", ""]
    sections = list(dict.fromkeys(r["section"] for r in rows))
    for sec in sections:
        lines += [f"## {sec}", "", "| Item | SKU | Qty | Unit ₹ | Total ₹ | Need | Note |",
                  "|---|---|---|---|---|---|---|"]
        for r in rows:
            if r["section"] == sec:
                lines.append(f"| {r['item']} | {r['sku']} | {r['qty']} | {r['unit_inr']:,} | {r['total_inr']:,} | "
                             f"{r['need']} | {r['note']} |")
        lines.append(f"| **Subtotal** | | | | **{total(lambda r, s=sec: r['section'] == s):,}** | | |")
        lines.append("")
    lines += ["## 3D-printed parts (robu.in printing service)", "", PRINT_SERVICE_NOTE, "",
              "## Totals", "",
              "| | ₹ |", "|---|---|",
              f"| Required parts + tools | **{total(lambda r: r['need'] == 'required'):,}** |",
              f"| + recommended (bench power supply) | {total(lambda r: r['need'] == 'recommended'):,} |",
              f"| + optional (second battery) | {total(lambda r: r['need'] == 'optional'):,} |",
              "| + 3D printing (estimate) | 3,500-6,000 |",
              f"| **Everything** | **≈ {total(lambda r: True) + 4500:,}** |", "",
              "Servos are about 55% of the required cost. To start cheaper you could build the 4 legs first and add the",
              "claw arms later (8 fewer servos, about ₹17,000 less), but the single order above is complete.", ""]
    (HERE / "BOM.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"required {total(lambda r: r['need'] == 'required'):,} INR | all items {total(lambda r: True):,} INR "
          f"-> hardware/BOM.md, hardware/BOM.csv")


if __name__ == "__main__":
    main()
