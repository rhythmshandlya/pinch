# Building the crab: beginner's guide

You need: the robu.in order ([BOM.md](BOM.md)), the printed parts (26 pieces from
[cad/out/print/](../cad/out/print), quantities in [print_sheet.csv](../cad/out/print_sheet.csv)),
a laptop, a table you can solder on, and an afternoon per stage. Read the
[electronics safety rules](electronics.md#safety-rules-read-before-first-power-up) first.

> Every step has been rehearsed in the simulator. When something in this guide says
> "run X", that script exists in this project and already passes in simulation.

---

## Stage 0: order

1. Add the **required** items from [BOM.md](BOM.md) to the robu.in cart, plus the recommended bench power supply.
   Check that the servo is the **7.4 V / 19.5 kg·cm** ST3215 (SKU R258500).
2. Open the [robu.in 3D printing service](https://robu.in/product/3d-printing-service1/). Upload the 10 STL files from
   `cad/out/print/`, choose **PETG** (and **TPU** for `foot_tip`), and set quantities from `print_sheet.csv`:
   chassis 1, top_shell 1, coxa_link 6, femur_link 4, tibia 4, foot_tip 4, upper_arm 2, forearm 2, dactyl_L 1, dactyl_R 1.
   Print orientation hints are in `print_sheet.csv`.
3. To regenerate files after a design change, run `python cad/build.py`.

## Stage 1: set up the Raspberry Pi (no robot needed)

1. Flash **Raspberry Pi OS Lite (64-bit)** to the microSD with Raspberry Pi Imager (free). In the imager settings,
   set Wi-Fi, a username and **enable SSH**.
2. Boot the Pi with its own USB-C charger, then SSH in from your laptop: `ssh <user>@<pi-name>.local`.
3. Enable the camera and I2C, then install the software:
   ```bash
   sudo raspi-config nonint do_i2c 0
   sudo apt update && sudo apt install -y python3-picamera2 python3-venv git
   python3 -m venv --system-site-packages ~/crab-venv && source ~/crab-venv/bin/activate
   pip install numpy rustypot adafruit-circuitpython-bno055
   ```
4. Copy this project folder to the Pi (for example with `scp -r robotic-crab <user>@<pi-name>.local:~`).

## Stage 2: prepare every servo (one at a time)

New servos all have ID 1, so they must be set up **one at a time, before assembly**.

1. Solder the **power hub** first (Stage 4, steps 1-3), or temporarily power one servo from the bench supply at 7.4 V.
2. Connect **one** servo to the FE-URT-1 and the FE-URT-1 to the Pi by USB.
3. Run `python robot/setup_servo.py --id N`, with N from the
   [ID map](electronics.md#servo-id-map-matches-crabparamspy-joint_names-order). The servo moves to its centre position.
4. **Stick a label with the ID on it.** Leave it centred; you'll fit its horn in this position.
5. Repeat for all 20 (and the 2 spares as 21 and 22, renumbered later if one replaces a broken servo).

> On the Pi, first check the rustypot method names used in `robot/setup_servo.py` against your
> installed version (`python -c "import rustypot; help(rustypot.Sts3215PyController)"`). They
> couldn't be tested without hardware.

## Stage 3: mechanics

**Heat-set inserts.** Set the soldering iron to about 220 °C. Place an insert on its hole and press it in
gently and straight, until it's flush with the surface. Put them in:
* chassis: 6 × M3 in the shell bosses, 4 × M3 on the rear electronics posts, 4 × M2.5 on the Pi posts

**Horns.** Every joint is built **with the servo centred** (Stage 2), so the link should be fitted in its
*straight* calibration position (see `robot/calibrate.py`). The 25-tooth spline lands within ±7°;
calibration measures the rest.

For each leg (4×):
1. **Yaw servo** into its chassis pocket, output end pointing outward. Fit 2 × M2×6 diagonally through
   the base plate into the servo's bottom face.
2. **Coxa link**: put the femur servo (case hanging down, horn facing *backward* on the left legs,
   *forward* on the right legs) into the cradle, with 2 × M2×6 per side. Bolt the coxa link's top plate to the yaw
   servo's horn with 4 × M3×6, with the leg pointing straight out.
3. **Femur link**: knee servo into the cradle (case toward the hip, horn on the opposite side to the
   femur servo's horn), 2 × M2×6 per side (M2×8 on the thick side). Bolt it to the femur servo horn
   (4 × M3×6) with the thigh horizontal.
4. **Tibia**: bolt it to the knee horn (4 × M3×6) with the shin in line with the thigh. Slide the TPU foot tip on and fix it with an M3×25.

For each arm (2×): same pattern. Shoulder bracket (same part as the coxa link) → upper arm (elbow servo
case pointing forward) → forearm (claw servo) → dactyl (`dactyl_L` on the left arm, `dactyl_R` on the right).

Check by hand that every joint turns freely over its range (`crab/params.py`). The CAD check
(`python cad/check.py`) says nothing collides, but print tolerances can.

## Stage 4: electronics (soldering)

Follow the [wiring table](electronics.md#wiring-table).
1. **Power hub**: on the prototype PCB, solder two thick bus strips (16 AWG wire laid along a row) for V+ and GND,
   and 6 × 3-pin header groups, pin order **GND / V+ / Signal**. Join all Signal pins together.
2. Solder the XT60 lead → switch → fuse holder → both buck converters (red to +, black to −). Use heat-shrink on every joint.
3. **Before connecting anything to the regulators**: power the input from the bench supply, then adjust the 20 A buck to **7.40 V**
   and the 5 V buck to **5.10 V**, measuring with the multimeter.
4. Wire the 7.4 V buck → hub bus, the FE-URT-1 TTL signal + GND → hub signal + GND, and the 5 V buck → Pi GPIO pins 2 and 6.
5. IMU to Pi pins 1/3/5/9, mounted flat on the electronics deck with its **x arrow pointing forward**.
6. Camera into the window at the front of the shell, cable to the Pi's CAM port.
7. Daisy-chain each limb: hub → yaw → femur → knee (legs), hub → shoulder yaw → pitch → elbow → claw (arms).

## Stage 5: first power-up (bench supply)

1. Battery out. Set the bench supply to **7.4 V with a 2 A current limit**, clipped onto the XT60 lead.
2. Switch on. The current should stay well under 1 A with torque off. If the supply hits the limit, switch off and look for a short.
3. On the Pi: `python robot/calibrate.py`. Hold the crab in the straight pose when asked.
4. `python robot/run.py --emote wave`, still on the bench supply (raise the limit to 4 A). The left claw should wave.
   If a joint moves the **wrong way**, flip its sign in `robot/calibration.json`.

## Stage 6: on its own feet

1. Charge the battery (SkyRC E3, in the LiPo bag). Strap it under the body and plug in the buzzer.
2. `python robot/run.py` runs the demo: wave, happy, walk forward, crab-walk left and right, turn, angry, sleep.
3. Low battery: the buzzer sounds and the software stops cleanly at 6.4 V. Recharge then.

## Stage 7: smarter

* **Learned walking**: train on Colab with [training/colab_train.ipynb](../training/colab_train.ipynb), copy the result into
  `training/checkpoints/`, test it with `python sim/walk.py --policy ...`, then run `python robot/run.py --policy ...`.
* **Brain**: run Ollama with Gemma 4 on your PC (`ollama pull gemma4:e4b`), then on the Pi run
  `python brain/run_brain.py --host http://<pc-ip>:11434`.

## If something goes wrong

| Symptom | Likely cause |
|---|---|
| A servo doesn't answer | Wrong ID, or two servos share an ID. Unplug the others and run `setup_servo.py` on it alone |
| Joint jerks or vibrates | Loose horn screws, or that servo's P gain isn't 32 |
| Robot sags or drifts | Calibration is off. Redo `calibrate.py` carefully |
| Pi reboots when walking | Pi power shares the servo regulator, or a weak 5 V buck. It needs its own 5 V 5 A supply |
| Battery runs out fast | Normal: about 25 min of walking. Carry the second battery |
