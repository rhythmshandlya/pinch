# Electronics design

All parts from robu.in (SKUs in [BOM.md](BOM.md)). Numbers come from the simulator
(`python sim/power.py`) and the servo reference ([ST3215_reference.md](ST3215_reference.md)).

## Block diagram

```mermaid
flowchart LR
    BAT["2S LiPo 7.4 V 3300 mAh<br/>(XT60, under the body)"] --> SW["Main switch"]
    SW --> FUSE["20 A blade fuse"]
    FUSE --> BUCK7["20 A buck → 7.4 V<br/>servo power"]
    FUSE --> BUCK5["5 V 5 A buck<br/>Pi power"]
    BUCK7 --> HUB["Power hub (perfboard)<br/>16 AWG bus, 6 limb headers"]
    HUB --> LFL["Front-left leg<br/>IDs 1-3"]
    HUB --> LFR["Front-right leg<br/>IDs 4-6"]
    HUB --> LRL["Rear-left leg<br/>IDs 7-9"]
    HUB --> LRR["Rear-right leg<br/>IDs 10-12"]
    HUB --> AL["Left arm<br/>IDs 13-16"]
    HUB --> AR["Right arm<br/>IDs 17-20"]
    BUCK5 --> PI["Raspberry Pi 5 4GB"]
    PI -- "USB" --> URT["Feetech FE-URT-1<br/>USB → servo signal"]
    URT -- "signal + GND" --> HUB
    PI -- "I2C" --> IMU["BNO055 IMU"]
    PI -- "CSI" --> CAM["Camera Module 3 wide"]
    BAT -. "balance lead" .-> ALARM["LiPo voltage buzzer"]
```

## Why it's built this way

- **Servo voltage.** The 7.4 V ST3215 is rated for **4–7.4 V**, but a full 2S LiPo is **8.4 V**.
  A buck regulator set to 7.4 V caps the voltage while the battery is full. As the battery
  drains, it passes the battery voltage straight through, which is fine for the servos.
- **Power doesn't go through the signal board.** The FE-URT-1 converts the signal only. Its
  power pass-through is limited to 6 A, and walking peaks at 7 A. Servo power goes from the
  buck through the hub on thick 16 AWG wire.
- **Six short chains instead of one long one.** Each servo connector pin is rated about 3 A.
  One chain per limb keeps each chain at 3–4 servos.
- **The Pi gets its own regulator,** so servo current spikes can't brown it out and reset it.
- **The battery sits under the body.** This lowers the centre of mass and makes swaps easy.

## Power budget (simulated, measured ST3215 motor model)

| Activity | Servo current avg / peak | Battery current | Runtime, 3300 mAh (80% usable) |
|---|---|---|---|
| Standing | 1.9 / 2.1 A | 3.5 A | ~46 min |
| Idle / wave emotes | 2.2 / 3.0 A | 3.8 A | ~42 min |
| Happy dance | 3.5 / 5.5 A | 5.2 A | ~30 min |
| Trot forward | 4.1 / 5.4 A | 5.9 A | ~27 min |
| Trot sideways (worst) | 4.7 / 6.9 A | 6.6 A | ~24 min |

Pi 5 and camera are assumed at 9 W and the regulators at 90% efficiency. The 20 A buck and
20 A fuse leave about 3× headroom over walking peaks. That covers stalls and falls, where
several servos can pull up to 2.5 A each at once.

## Wiring table

| From | To | Wire / connector | Notes |
|---|---|---|---|
| Battery XT60 | Main switch | 16 AWG silicone, XT60 pigtail | Red = +, black = − |
| Switch | Fuse holder | 16 AWG | 20 A mini blade fuse |
| Fuse | 7.4 V buck IN+ / IN− | 16 AWG | **Set the output to 7.40 V with a multimeter before connecting servos** |
| Fuse | 5 V buck IN+ / IN− | 18–20 AWG | Set the output to 5.10 V |
| 7.4 V buck OUT | Power hub bus | 16 AWG | Solder to the perfboard bus strips |
| Power hub | 6 limb headers | 3-pin 2.54 mm headers (Molex 5264-compatible) | Pin order **GND, V+, Signal** (as on the servo) |
| FE-URT-1 TTL port | Power hub signal + GND | Servo cable | Only signal and GND. Don't feed hub power back into the FE-URT-1 |
| FE-URT-1 USB (Mini-B) | Pi USB-A | USB-A to Mini-B cable | Shows up as `/dev/ttyUSB0`; set it to 1 Mbps |
| 5 V buck OUT | Pi GPIO pin 2 (5 V) + pin 6 (GND) | 20 AWG, female jumpers | Or a USB-C pigtail |
| IMU BNO055 | Pi pin 1 (3.3 V), 3 (SDA), 5 (SCL), 9 (GND) | Qwiic / jumper | I2C address 0x28 |
| Camera | Pi CAM port | Pi 5 FPC cable 200 mm | The Pi 5 uses the smaller 22-pin connector |
| Battery balance lead | LiPo buzzer | JST-XH | Set the alarm to 3.5 V per cell |

Inside each limb the servos daisy-chain with the cables that come with them: hub → yaw → femur → knee
on legs, hub → shoulder yaw → shoulder pitch → elbow → claw on arms.

## Servo ID map (matches `crab/params.py` JOINT_NAMES order)

| ID | Joint | ID | Joint | ID | Joint | ID | Joint |
|---|---|---|---|---|---|---|---|
| 1 | FL_coxa | 6 | FR_tibia | 11 | RR_femur | 16 | L_claw |
| 2 | FL_femur | 7 | RL_coxa | 12 | RR_tibia | 17 | R_shoulder_yaw |
| 3 | FL_tibia | 8 | RL_femur | 13 | L_shoulder_yaw | 18 | R_shoulder_pitch |
| 4 | FR_coxa | 9 | RL_tibia | 14 | L_shoulder_pitch | 19 | R_elbow |
| 5 | FR_femur | 10 | RR_coxa | 15 | L_elbow | 20 | R_claw |

New servos all ship as **ID 1**. `robot/setup_servo.py` assigns IDs one servo at a time.

## Servo settings written by the setup script

| Register | Value | Why |
|---|---|---|
| P / I / D gains | 32 / 0 / 0 | These are the gains the measured (BAM) model was identified with, same as Open Duck Mini |
| Max input voltage (addr 14) | 80 (8.0 V) | Protects the servos if the regulator fails and passes 8.4 V |
| Min input voltage (addr 15) | 60 (6.0 V) | Servos stop before the LiPo is over-drained |
| Torque limit (addr 48) | 1000 | Full torque; the software applies its own limits |
| Return delay (addr 7) | 0 | Faster bus |

## Safety rules (read before first power-up)

1. **First power-up on the bench supply**, not the LiPo. Use 7.4 V with the current limit at **2 A**.
   A wiring mistake then just trips the limit instead of burning something.
2. **Check polarity with the multimeter** at every connector before plugging in a servo.
3. Set the buck output to **7.40 V with nothing connected**, then connect the hub.
4. Charge LiPos **only in a fire-safe place, never unattended**, with the balance charger set to
   2S LiPo at 1 C (3.3 A max).
5. Stop when the buzzer sounds (3.5 V per cell). The software also warns at 6.6 V and stops at 6.4 V
   under load.
6. If a battery is **puffy, dented or hot**, stop using it and dispose of it at an e-waste point.
